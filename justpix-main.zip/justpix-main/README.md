# SPA Authentication using Laravel 9 Sanctum, Vue 3 and Vite

```
/cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan storage:link
php artisan db:seed
npm install
npm run prod
```
