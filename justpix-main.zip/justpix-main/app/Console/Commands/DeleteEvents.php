<?php

namespace App\Console\Commands;

use App\Models\Event;
use App\Models\Package;
use Carbon\Carbon;
use Illuminate\Console\Command;

class DeleteEvents extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'justpix:delete-events';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $packages = Package::whereHas('events')->get();
        foreach ($packages as $package){
            $exp = Carbon::now()->subMonths($package->months)->format('Y-m-d');
            $events = Event::where('package_id', $package->id)->where('date', 'like', '%'.$exp.'%')->get();
            foreach ($events as $event)
            {
                $event->payments()->delete();
                $event->guests()->delete();
                $event->media()->delete();
                $event->messages()->delete();
                $event->delete();
            }
        }
        return Command::SUCCESS;
    }
}
