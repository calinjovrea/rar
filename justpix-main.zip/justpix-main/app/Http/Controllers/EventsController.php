<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Guest;
use App\Models\Message;
use App\Models\Payment;
use App\Models\User;
use http\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Spatie\MediaLibrary\Support\MediaStream;

class EventsController extends Controller
{
    public function index(User $user)
    {
        $events = Auth::user()->events;
        return response()->json($events);
    }
    public function getAllEvents(Request $request)
    {
        $events = Event::with([
            'user',
            'package',
            'payments'
        ])
            ->applyFilters($request->only('search','page'))
            ->orderBy('created_at', 'desc')->paginate(15);
        return response()->json($events);
    }

    public function store(User $user, Request $request)
    {
        $event = new Event($request->all());
        $event->user_id = Auth::id();
        $event->hash = Str::random(30);
        $event->save();
        $hash = env('APP_URL') . '/events/' . $event->hash;
        $qr = base64_encode(QrCode::format('png')->size(500)->generate($hash));
        $event->addMediaFromBase64($qr)->usingFileName($event->hash . '.png')->toMediaCollection('hash');
        if ($request->featured) {
            $event->addMedia($request->featured['path'])->usingName($request->featured['name'])->toMediaCollection('featured');
        }
        if (Auth::user()->hasRole('Superadmin')){
            $payment = new Payment();
            $payment->stripe_id = 'free-'.Str::random(8);
            $payment->user_id = Auth::id();
            $payment->event_id = $event->id;
            $payment->package_id = $event->package_id;
            $payment->price = 0;
            $payment->save();
        }
        return response()->json('success', 200);
    }

    public function update(User $user, Event $event, Request $request)
    {
        $event->update($request->all());
        return response()->json('success', 200);
    }

    public function fetch(User $user, Event $event)
    {
        $event->load('package', 'messages', 'messages.guest', 'guests');
        $payment = $event->payments()->where('package_id', $event->package->id)->first();
        $event->payment = $payment;
        $pics = $event->media()->where('collection_name', 'pics')->paginate(4);
        $event->pics = $pics;
        return response()->json($event);
    }

    public function getForGuest($guest, $hash, Request $request)
    {
        $event = Event::where('hash', $hash)->first();
        $guest = Guest::where('hash', $guest)->first();
        $event->load(['messages', 'messages.guest', 'payments', 'package']);
        if ($request->gallery){
            $pics = $event->media()->where('collection_name', 'pics')->paginate(400);
        }else{
            $pics = $event->media()->where('collection_name', 'pics')->where('custom_properties->guest_id', $guest->id)->paginate(400);
        }
        $event->pics = $pics;
        return response()->json($event);
    }

    public function getClientPics(User $user, Event $event, Request $request)
    {
        $pics = $event->media()->where('collection_name', 'pics')->paginate(4);

        return response()->json($pics);
    }

    public function getPics($guest, $hash, Request $request)
    {
        $event = Event::where('hash', $hash)->first();
        $guest = Guest::where('hash', $guest)->first();
        if ($request->gallery){
            $pics = $event->media()->where('collection_name', 'pics')->paginate(4);
        }else{
            $pics = $event->media()->where('collection_name', 'pics')->where('custom_properties->guest_id', $guest->id)->paginate(4);
        }
        return response()->json($pics);
    }

    public function message($guest, $hash, Request $request)
    {
        $guest = Guest::where('hash', $guest)->first();
        $event = Event::where('hash', $hash)->first();
        $message = new Message();
        $message->event_id = $event->id;
        $message->guest_id = $guest->id;
        $message->body = $request->body;
        $message->save();
        return response()->json("success", 200);
    }
    public function loginGuest(Event $event, Request $request)
    {
        $guest = Guest::where('phone', $request->phone)->where('event_id', $event->id)->first();
        if ($guest) {
            if (($event->pin && $request->pin === $event->pin)||!$event->pin){
                return response()->json($guest);
            }
        }else{
            if (!$event->pin){
                $guest = new Guest($request->all());
                $guest->event_id = $event->id;
                $guest->hash = Str::random(8);
                $guest->save();
                return response()->json($guest);
            }
        }
        return response()->json('Date autentificare incorecte', 422);
    }
    public function upload($guest, $hash, Request $request)
    {
        $event = Event::where('hash', $hash)->first();
        $guest = Guest::where('hash', $guest)->first();
        foreach ($request->images as $file) {
            $name = Str::random(30).'.'.$file->getClientOriginalExtension();
            $event->addMedia($file)->usingName($name)->withCustomProperties(['guest_id' => $guest->id])->toMediaCollection('pics');
        }
        return  response()->json('success', 200);
    }
    public function singleUpload(Request $request)
    {
        if (count($request->images)) {
            $file = $request->images[0];
            $name = $file->getClientOriginalName();
            $temp = time() . '-' . $name;
            Storage::disk('public')->putFileAs('temp/', $file, $temp);
            $path = Storage::disk('public')->path('temp/' . $temp);
            $url = Storage::disk('public')->url('temp/' . $temp);
            $resp = ['name' => $name, 'path' => $path, 'url' => $url];
            return  response()->json($resp);
        }
        return response()->json('error', 400);
    }

    public function deletePhoto($guest, Media $media)
    {
        $guest = Guest::where('hash',$guest)->first();
        if ($guest){
            if ($media->custom_properties["guest_id"] == $guest->id) {
                $media->delete();
            }
        }
        return response()->json('success', 200);
    }

    public function deleteClientPhoto(User $user, Media $media)
    {
        $media->delete();

        return response()->json('success', 200);
    }

    public function zip($guest, $hash, Request $request)
    {
        $event = Event::where('hash', $hash)->first();
        $zip_file = Str::random(8) . '.zip';
        $downloads = $event->getMedia('pics')->whereIn('id', $request->images);

        return MediaStream::create($zip_file)->addMedia($downloads);
    }

    public function zipClient($user, Event $event, Request $request)
    {
        $zip_file = Str::random(8) . '.zip';
        $downloads = $event->getMedia('pics')->whereIn('id', $request->images);

        return MediaStream::create($zip_file)->addMedia($downloads);
    }

    public function updateImage(User $user, Event $event, Request $request)
    {
        if (count($request->images)) {
            $file = $request->images[0];
            $name = $file->getClientOriginalName();
            $event->addMedia($file)->usingName($name)->toMediaCollection('featured');
            return  response()->json('success', 200);
        }
        return response()->json('error', 400);
    }

    public function storeGuest(User $user, Event $event, Request $request)
    {
        $guest = new Guest($request->all());
        $guest->hash = Str::random(8);
        $guest->save();
        return $this->fetch($user, $event);
    }

    public function deleteGuest(User $user, Event $event, Request $request)
    {
        $guest = Guest::find($request->id);
        if ($guest) {
            $guest->delete();
        }
        return $this->fetch($user, $event);
    }
}
