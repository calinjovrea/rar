<?php

namespace App\Http\Controllers;

use App\Models\Package;
use Illuminate\Http\Request;

class PackagesController extends Controller
{
    public function index()
    {
        $packages = Package::orderBy('price', 'asc')->get();
        return response()->json($packages);
    }
    public function store(Request $request)
    {
        $package = new Package($request->all());
        if ($request->featured){
            $featured = Package::where('featured', 1)->get();
            if ($featured->count()){
                foreach ($featured as $feat){
                    $feat->update(['featured' => 0]);
                }
            }
        }
        $package->save();
        return response()->json('success', 200);
    }

    public function update(Package $package, Request $request)
    {
        $package->fill($request->except('featured'));
        if ($request->featured){
            $featured = Package::where('featured', 1)->get();
            if ($featured->count()){
                foreach ($featured as $feat){
                    $feat->update(['featured' => 0]);
                }
            }
            $package->featured = $request->featured;
        }
        $package->update();
        return response()->json('success', 200);
    }

    public function fetch(Package $package)
    {
        return response()->json($package);
    }

    public function delete(Package $package)
    {
        $package->delete();
        return response()->json('success', 200);
    }
}
