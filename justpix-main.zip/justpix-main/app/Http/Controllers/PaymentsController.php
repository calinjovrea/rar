<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Http\Request;
use Stripe\Customer;
use Stripe\PaymentIntent;
use Stripe\Stripe as StripeGateway;

class PaymentsController extends Controller
{
    public function initiatePayment(User $user, Event $event, Request $request)
    {
        $package = $event->package;
        $limit = $package->limit?'Maxim .'.$package->limit.' GB upload':'Fara limita de upload';
        $description = $package->name.' | '.$package->min_guests.' - '.$package->max_guests.' invitati | '.$limit.' | '.($package->price/100).' RON';

        StripeGateway::setApiKey(env('STRIPE_SECRET'));

        if (!$user->stripe_id){
            $customer = Customer::create([
                'name' => $user->name,
                'email' => $user->email
            ]);
            $user->stripe_id = $customer->id;
            $user->update();
        }

        $intent = PaymentIntent::create([
            'amount' => $package->price,
            'currency' => 'ron',
            'metadata' => ['event_id' => $event->id, 'package_id' => $package->id],
            'description' => $description,
            'customer' => $user->stripe_id
        ]);

        return response()->json($intent);
    }

    public function completePayment(User $user, Event $event, Request $request)
    {
        StripeGateway::setApiKey(env('STRIPE_SECRET'));
        $paymentIntent = PaymentIntent::retrieve($request->id,[]);
        $payment = new Payment();
        $payment->user_id = $user->id;
        $payment->stripe_id = $paymentIntent['id'];
        $payment->price = $paymentIntent['amount'];
        $payment->event_id = $paymentIntent['metadata']['event_id'];
        $payment->package_id = $paymentIntent['metadata']['package_id'];
        $payment->save();

        $event->load('package', 'messages', 'guests');
        $e_payment = $event->payments()->where('package_id', $event->package->id)->first();
        $event->payment = $e_payment;
        return response()->json($event);

        return response()->json('success', 200);
    }
}
