<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UsersController extends Controller
{
    public function index()
    {
        $users = User::whereHas('roles', function ($q){
            $q->where('id', '<', 3);
        })->get();
        return response()->json($users);
    }

    public function store(Request $request)
    {
        $existingUser = User::where('email', $request->email)->first();
        if ($existingUser){
            $existingUser->syncRoles([$request->role]);
        }else{
            $user = new User($request->except('role'));
            $user->password = Hash::make(Str::random(8));
            $user->save();
            $user->assignRole($request->role);
        }
        return response()->json('success', 200);
    }

    public function update(User $user, Request $request)
    {
        $user->update($request->except('role'));
        $user->syncRoles([$request->role]);
        return response()->json('success', 200);
    }

    public function delete(User $user)
    {
        $events = $user->events;
        if ($events->count()){
            $user->syncRoles([3]);
        }else{
            $user->delete();
        }
        return response()->json('success', 200);
    }

    public function fetch(User $user)
    {
        return response()->json($user);
    }
}
