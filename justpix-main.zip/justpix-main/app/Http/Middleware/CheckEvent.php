<?php

namespace App\Http\Middleware;

use App\Models\Event;
use App\Models\Guest;
use Closure;
use Illuminate\Http\Request;

class CheckEvent
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $guest = Guest::where('hash', $request->guest)->first();
        $event = Event::where('hash', $request->hash)->first();
        if (!$guest||!$event||$guest->event_id!==$event->id){
            abort(403, 'Nu esti autorizat sa accesezi aceasta pagina');
        }
        return $next($request);
    }
}
