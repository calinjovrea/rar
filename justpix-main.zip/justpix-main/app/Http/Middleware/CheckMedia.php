<?php

namespace App\Http\Middleware;

use App\Models\Guest;
use Closure;
use Illuminate\Http\Request;

class CheckMedia
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $guest = Guest::where('hash', $request->guest)->first();
        $media = $request->media;
        if (!$guest||!$media||$guest->id!==$media->custom_properties['guest_id']){
            abort(403, 'Nu esti autorizat sa accesezi aceasta pagina');
        }
        return $next($request);
    }
}
