<?php

namespace App\Http\Middleware;

use App\Models\Event;
use Closure;
use Illuminate\Http\Request;

class CheckMediaUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user;
        $media = $request->media;
        $event = Event::where('user_id', $user->id)->where('id', $media->model_id)->first();
        if (!$event) {
            abort(403, 'Nu esti autorizat sa accesezi aceasta pagina');
        }
        return $next($request);
    }
}
