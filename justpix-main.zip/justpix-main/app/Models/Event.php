<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\File;

class Event extends Model implements HasMedia
{
    use HasFactory, InteractsWithMedia;

    protected $fillable = ['name', 'welcome', 'date', 'package_id', 'pin'];
    protected $dates = ['date'];

    protected $appends = ['qrcode', 'featured', 'picsCount', 'picsSize'];


    public function getQrcodeAttribute()
    {
        return $this->getFirstMediaUrl('hash');
    }

    public function getFeaturedAttribute()
    {
        return $this->getFirstMediaUrl('featured');
    }

    public function getPicsCountAttribute()
    {
        return $this->getMedia('pics')->count();
    }

    public function getPicsSizeAttribute()
    {
        return $this->getMedia('pics')->sum('size');
    }

    public function registerMediaCollections(): void
    {
        $this
            ->addMediaCollection('hash')
            ->useDisk('public')
            ->acceptsFile(function (File $file) {
                return $file->mimeType === 'image/png';
            })
            ->singleFile();
        $this
            ->addMediaCollection('featured')
            ->useDisk('public')
            ->acceptsMimeTypes(['image/jpeg', 'image/png'])
            ->singleFile();
        $this
            ->addMediaCollection('pics')
            ->useDisk('s3')
            ->acceptsMimeTypes(['image/jpeg', 'image/png', 'video/mp4', 'video/quicktime']);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function package()
    {
        return $this->belongsTo(Package::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function guests()
    {
        return $this->hasMany(Guest::class);
    }

    public function messages()
    {
        return $this->hasMany(Message::class);
    }

    public function scopeApplyFilters($query, array $filters)
    {
        $filters = collect($filters);
        if($filters->get('search')){
            $query->whereSearch($filters->get('search'));
        }
    }

    public function scopeWhereSearch($query, $search)
    {
        $query->where('name', 'LIKE', '%'.$search.'%')
            ->orWhereHas('user', function ($q) use ($search){
                $q->where('name', 'LIKE', '%'.$search.'%')
                    ->orWhere('email', 'LIKE', '%'.$search.'%')
                    ->orWhere('phone', 'LIKE', '%'.$search.'%');
            });
    }
}
