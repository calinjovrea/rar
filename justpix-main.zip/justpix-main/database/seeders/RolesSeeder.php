<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class RolesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $role = Role::create(['name' => 'Superadmin']);
        $role = Role::create(['name' => 'Admin']);
        $role = Role::create(['name' => 'Client']);

        $user = new User();
        $user->name = '';
        $user->email = '';
        $user->password = Hash::make('');
        $user->save();

        $user->assignRole('Superadmin');
    }
}
