import './bootstrap';
import { createApp } from 'vue'

import VueNotifications from 'vue-notifications'
import miniToastr from 'mini-toastr'// https://github.com/se-panfilov/mini-toastr

const toastTypes = {
    success: 'success',
    error: 'error',
    info: 'info',
    warn: 'warn'
}

miniToastr.init({ types: toastTypes })

function toast({ title, message, type, timeout, cb }) {
    return miniToastr[type](message, title, 3000, cb)
}

const options = {
    success: toast,
    error: toast,
    info: toast,
    warn: toast
}

import router from "@/router";
import store from '@/store'
import App from "@/App.vue";

import VueSweetalert2 from 'vue-sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';

const sweetOptions = {
    confirmButtonColor: '#F97316'
};

import VueSelect from "vue-select";
import "vue-select/dist/vue-select.css";

import VueDatePicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css';

import spinkit from '@/components/spinkit';

global.axios.interceptors.response.use(undefined, function (err) {
    // Do something with request error
    if (!err.response) {
        window.toast['error']('Network error: Please check your internet connection or wait until servers are back online')
        console.log('Network error: Please check your internet connection.')
    } else {
        console.log(err.response)
        if (err.response.data && (err.response.statusText === 'Unauthorized' || err.response.data === ' Unauthorized.' || err.response.status === 401)) {
            // Unauthorized and log out
            toast({
                title: '401',
                message: 'Trebuie sa fii autentificat ca sa accesezi aceasta pagina',
                type: 'error',
                timeout: 3000
            })
            store.dispatch('auth/logout', true)
        } else {
            // Unknown error
            toast({
                title: '',
                message: (err.response.data.message) ? err.response.data.message : 'A aparut o eroare',
                type: 'error',
                timeout: 3000
            })
        }
    }
    return Promise.reject(err)
})

const app = createApp(App)

app.component("v-select", VueSelect)
app.component('VueDatePicker', VueDatePicker);
app.component('spinkit', spinkit);

app.use(router);
app.use(store);
app.use(VueNotifications, options);
app.use(VueSweetalert2, sweetOptions);

app.mount('#app');

