<template>
    <div class="mx-auto my-3">
    <div class="flex justify-end">
        <ul class="pagination bg-white p-2 text-xs list-none">
            <li class="pagination-item">
				<ChevronDoubleLeftIcon
                    class="cursor-not-allowed no-underline text-gray-600 h-3 w-3 me-2"
                    v-if="isInFirstPage"
                ></ChevronDoubleLeftIcon>
                <ChevronDoubleLeftIcon
                    v-else
                    @click.prevent="onClickFirstPage"
                    class="no-underline text-gray-600 h-3 w-3 me-2"
                    href="#"
                    role="button"
                    rel="prev"
                >
                </ChevronDoubleLeftIcon>
            </li>

            <li class="pagination-item">
                <ChevronLeftIcon
                    role="button"
                    @click="onClickPreviousPage"
                    :disabled="isInFirstPage"
                    aria-label="Go to previous page"
                    class="no-underline text-gray-600 h-3 w-3 me-2"
                    :class="{'cursor-not-allowed': isInFirstPage}"
                >&lt;</ChevronLeftIcon>
            </li>

            <li
                v-for="page in pages"
                class="pagination-item"
                :key="page.name"
            >
				<span
                    class="border border-blue-100 px-3 py-1 bg-orange-100 no-underline text-blue-500 cursor-not-allowed mx-1 rounded-xl"
                    v-if="isPageActive(page.name)"
                >{{ page.name }}</span>
                <a
                    class="border border-gray-100 px-3 py-1 hover:bg-gray-100 text-gray-600 no-underline mx-1 rounded-xl"
                    href="#"
                    v-else
                    @click.prevent="onClickPage(page.name)"
                    role="button"
                >{{ page.name }}</a>
                <!-- <button
                    type="button"
                    @click="onClickPage(page.name)"
                    :disabled="page.isDisabled"
                    :class="{ active: isPageActive(page.name) }"
                >{{ page.name }}</button> -->
            </li>

            <li class="pagination-item">
                <ChevronRightIcon
                    type="button"
                    @click="onClickNextPage"
                    :disabled="isInLastPage"
                    aria-label="Go to next page"
                    class="no-underline text-gray-600 h-3 w-3 ms-2"
                    :class="{'cursor-not-allowed': isInLastPage}"
                >&gt;</ChevronRightIcon>
            </li>

            <li class="pagination-item">
                <!-- <button
                    type="button"
                    @click="onClickLastPage"
                    :disabled="isInLastPage"
                    aria-label="Go to last page"
                >Last</button> -->
                <ChevronDoubleRightIcon
                    class="no-underline text-gray-600 h-3 w-3 ms-2"
                    href="#"
                    @click.prevent="onClickLastPage"
                    rel="next"
                    role="button"
                    v-if="hasMorePages"
                >&raquo;</ChevronDoubleRightIcon>
                <ChevronDoubleRightIcon
                    class="cursor-not-allowed no-underline text-gray-600 h-3 w-3 ms-2"
                    v-else
                >&raquo;</ChevronDoubleRightIcon>
            </li>
        </ul>
    </div>
    </div>
</template>
<script>
import { ChevronLeftIcon, ChevronRightIcon, ChevronDoubleLeftIcon, ChevronDoubleRightIcon } from '@heroicons/vue/24/outline'
export default {
    name:'Pagination',
    components:{ChevronLeftIcon,ChevronRightIcon, ChevronDoubleLeftIcon, ChevronDoubleRightIcon},
    props: {
        maxVisibleButtons: {
            type: Number,
            required: false,
            default: 3
        },

        totalPages: {
            type: Number,
            required: true
        },

        total: {
            type: Number,
            required: true
        },

        perPage: {
            type: Number,
            required: true
        },

        currentPage: {
            type: Number,
            required: true
        },
    },

    computed: {
        startPage() {
            if (this.currentPage === 1) {
                return 1;
            }

            if (this.currentPage === this.totalPages) {
                return this.totalPages - this.maxVisibleButtons + 1;
            }

            return this.currentPage - 1;
        },
        endPage() {
            return Math.min(
                this.startPage + this.maxVisibleButtons - 1,
                this.totalPages
            );
        },
        pages() {
            const range = [];

            for (let i = this.startPage; i <= this.endPage; i += 1) {
                range.push({
                    name: i,
                    isDisabled: i === this.currentPage
                });
            }

            return range;
        },
        isInFirstPage() {
            return this.currentPage === 1;
        },
        isInLastPage() {
            return this.currentPage === this.totalPages;
        },
        hasMorePages(){
            return this.totalPages > 1
        }
    },

    methods: {
        onClickFirstPage() {
            this.$emit("pagechanged", 1);
        },
        onClickPreviousPage() {
            if (!this.isInFirstPage){
                this.$emit("pagechanged", this.currentPage - 1);
            }
        },
        onClickPage(page) {
            this.$emit("pagechanged", page);
        },
        onClickNextPage() {
            if (!this.isInLastPage){
                this.$emit("pagechanged", this.currentPage + 1);
            }
        },
        onClickLastPage() {
            this.$emit("pagechanged", this.totalPages);
        },
        isPageActive(page) {
            return this.currentPage === page;
        }
    }
}
</script>

<style scoped>
.pagination-item{
    @apply inline-block cursor-pointer;
}
.active{
    @apply border-t border-b border-l border-blue-100 px-3 py-2 bg-blue-100 no-underline text-blue-500 text-sm;
}
</style>
