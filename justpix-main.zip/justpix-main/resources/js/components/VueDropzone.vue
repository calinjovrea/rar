<template>
    <div v-bind="getRootProps()" class="w-full p-12 border rounded-xl flex flex-col justify-center items-center text-center cursor-pointer">
        <input v-bind="getInputProps()" />
        <p v-if="isDragActive">Lasa imaginea aici ...</p>
        <p v-else>Apasa pentru a adauga imaginea sau trage imaginea aici</p>
        <CloudArrowUpIcon class="text-orange-500 w-12"></CloudArrowUpIcon>
    </div>
</template>

<script>
import { useDropzone } from "vue3-dropzone";
import { reactive } from 'vue'
import {CloudArrowUpIcon} from '@heroicons/vue/24/solid'

export default {
    name: "VueDropzone",
    emits:['filesUploaded','filesErrors', 'uploadError'],
    props:['multiple', 'maxFiles', 'accept', 'url'],
    components:{CloudArrowUpIcon},
    setup(props, {emit}) {
        const url = props.url; // Your url on the server side
        const saveFiles = (files) => {
            const formData = new FormData(); // pass data as a form
            for (let x = 0; x < files.length; x++) {
                // append files as array to the form, feel free to change the array name
                formData.append("images[]", files[x]);
            }

            // post the formData to your backend where storage is processed. In the backend, you will need to loop through the array and save each file through the loop.
            return new Promise((resolve, reject) => {
                window.axios
                    .post(url, formData, {
                        headers: {
                            "Content-Type": "multipart/form-data",
                        },
                    })
                    .then((response) => {
                        emit('filesUploaded', response)
                    })
                    .catch((err) => {
                        emit('uploadError', err)
                    });
                }
            )
        };

        function onDrop(acceptFiles, rejectReasons) {
            if (rejectReasons.length){
                emit('filesErrors', rejectReasons)
            }else{
                saveFiles(acceptFiles);
            }
        }
        const options = reactive({
            multiple: props.multiple,
            onDrop,
            accept: props.accept,
            maxFiles: props.maxFiles
        })

        const { getRootProps, getInputProps, ...rest } = useDropzone( options );

        return {
            getRootProps,
            getInputProps,
            ...rest,
        };
    },
};
</script>
