<template>
    <div class="relative">
        <nav class="bg-white fixed w-full z-20 top-0 start-0 border-b border-gray-200" v-if="!mobileNav">
            <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
                <a href="http://justpix.test" class="flex items-center space-x-3 rtl:space-x-reverse">
                    <img src="/images/logo.svg" alt="" class="h-12 w-auto">
                </a>
                <div class="flex md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse">
                    <div class="my-auto hidden md:block">
                        <router-link v-if="!isAuthenticated" to="/inregistrare" class="auth text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 text-center me-2">Creaza cont</router-link>
                        <router-link v-if="!isAuthenticated" to="/autentificare" class="auth text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 text-center">Login</router-link>
                        <button v-else @click="logout" class="auth text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 text-center">Logout</button>
                    </div>
                    <button data-collapse-toggle="navbar-sticky" type="button" class="inline-flex items-center p-2 justify-center text-3xl text-gray-500 rounded-lg md:hidden focus:outline-none leading-none" aria-controls="navbar-sticky" aria-expanded="false" @click="mobileNav=!mobileNav">
                        <span class="sr-only">Open main menu</span>
                        &#9776;
                    </button>
                </div>
                <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" v-if="!isAuthenticated">
                    <ul class="flex flex-col p-4 md:p-0 mt-4 font-medium border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white">
                        <li>
                            <router-link to="/" class="block py-2 px-3 text-gray-900 md:p-0 hover:text-gray-600" aria-current="page">Home</router-link>
                        </li>
                    </ul>
                </div>

                <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" v-else>
                    <ul class="flex flex-col p-4 md:p-0 mt-4 font-medium border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white" v-if="role<3">
                        <li>
                            <router-link to="/admin" class="block py-2 px-3 text-gray-900 md:p-0 hover:text-gray-600" aria-current="page">Dashboard</router-link>
                        </li>
                        <li v-if="role<2">
                            <router-link to="/admin/pachete" class="block py-2 px-3 text-gray-900 md:p-0  hover:text-gray-600">Pachete</router-link>
                        </li>
                        <li  v-if="role<2">
                            <router-link to="/admin/users" class="block py-2 px-3 text-gray-900 md:p-0  hover:text-gray-600">Utilizatori</router-link>
                        </li>
                        <li>
                            <router-link to="/client" class="block py-2 px-3 text-gray-900 md:p-0 hover:text-gray-600" aria-current="page">Evenimentele mele</router-link>
                        </li>
                    </ul>
                    <ul class="flex flex-col p-4 md:p-0 mt-4 font-medium border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white" v-else>
                        <li>
                            <router-link to="/client" class="block py-2 px-3 text-gray-900 md:p-0 hover:text-gray-600" aria-current="page">Dashboard</router-link>
                        </li>
                    </ul>
                </div>

            </div>
        </nav>
        <nav class="absolute w-full min-h-screen bg-black animate-open-menu origin-top flex-col justify-start z-10" :class="mobileNav?'flex':'hidden'" @click="mobileNav=!mobileNav">
            <ul class="flex flex-col justify-start w-full pt-12" v-if="isAuthenticated&&role<3">
                <li class="py-6 text-center w-full">
                    <router-link to="/admin" class="text-3xl text-white">Dashboard</router-link>
                </li>
                <li class="py-6 text-center w-full" v-if="role<2">
                    <router-link to="/admin/pachete" class="text-3xl text-white">Pachete</router-link>
                </li>
                <li class="py-6 text-center w-full" v-if="role<2">
                    <router-link to="/admin/users" class="text-3xl text-white">Utilizatori</router-link>
                </li>
                <li class="py-6 text-center w-full">
                    <router-link to="/client" class="text-3xl text-white">Evenimentele mele</router-link>
                </li>
            </ul>
            <ul class="flex flex-col justify-start w-full pt-12" v-if="isAuthenticated&&role>2">
                <hr class="w-1/2 mx-auto">
                <li class="py-6 text-center w-full">
                    <router-link to="/client" class="text-3xl text-white">Dashboard</router-link>
                </li>
            </ul>
            <ul class="flex flex-col justify-start w-full pt-12" v-if="!isAuthenticated">
                <li class="py-6 text-center w-full">
                    <router-link to="/" class="text-3xl text-white">Home</router-link>
                </li>
            </ul>
            <ul class="flex flex-col justify-start w-full">
                <hr class="w-1/2 mx-auto">
                <li class="py-6 text-center w-full" v-if="!isAuthenticated">
                    <router-link to="/inregistrare" class="auth text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-2xl px-6 py-2 text-center">Creaza cont</router-link>
                </li>
                <li class="py-6 text-center w-full" v-if="!isAuthenticated">
                    <router-link to="/autentificare" class="auth text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-2xl px-6 py-2 text-center">Login</router-link>
                </li>
                <li class="py-6 text-center w-full" v-else>
                    <button class="auth text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-2xl px-6 py-2 text-center" @click="logout">Logout</button>
                </li>
            </ul>
        </nav>
    </div>
    <main class="pt-36 pb-24 min-h-screen" :class="(isAuthenticated&&role>2)||!isAuthenticated?'bg-gradient-to-br from-white via-orange-100 to-white':''">
        <router-view></router-view>
    </main>
</template>

<script>
import {mapActions, mapGetters} from "vuex";
export default {
    name:'appContainer',
    data(){
        return{
            mobileNav:false
        }
    },
    computed:{
        ...mapGetters('auth',{
            isAuthenticated:'authenticated',
            role:'role'
        })
    },
    methods:{
        ...mapActions({
            signOut:"auth/logout"
        }),
        async logout(){
            await axios.post('/logout').then(({data})=>{
                this.signOut()
            })
        }
    }
}
</script>
<style>
.active {
    @apply text-orange-500 hover:text-orange-600;
}
.auth.active{
    @apply text-white hover:text-slate-100;
}
</style>
