import { createWebHistory, createRouter, RouterView } from "vue-router";
import store from '@/store'
import miniToastr from "mini-toastr";
const toastTypes = {
    success: 'success',
    error: 'error',
    info: 'info',
    warn: 'warn'
}

miniToastr.init({types: toastTypes})

function toast ({title, message, type, timeout, cb}) {
    return miniToastr[type](message, title, 3000, cb)
}

const routes = [
    {
        path: "/",
        component: RouterView,
        children: [
            {
                path: '/',
                component: () => import('@/containers/AppContainer'),
                redirect:'autentificare',
                children: [
                    {
                        path: 'inregistrare',
                        component: () => import('@/views/auth/Register'),
                        meta: {
                            middleware: 'guest'
                        },
                    },
                    {
                        path: 'autentificare',
                        component: () => import('@/views/auth/Login'),
                        meta: {
                            middleware: 'guest'
                        },
                    },
                    {
                        path: 'forgot-password',
                        component: () => import('@/views/auth/ForgotPassword'),
                        meta: {
                            middleware: 'guest'
                        },
                    },
                    {
                        path: 'reset-password/:token',
                        component: () => import('@/views/auth/ResetPassword'),
                        meta: {
                            middleware: 'guest'
                        },
                    },
                    {
                        path: 'events/:hash',
                        component: () => import('@/views/guest/EventView')
                    },
                    {
                        path: 'events/:hash/message',
                        component: () => import('@/views/guest/EventMessage')
                    },
                    {
                        path: 'events/:hash/gallery',
                        component: () => import('@/views/guest/EventGallery')
                    },
                    {
                        path: 'admin',
                        component: () => import('@/views/admin/Dashboard'),
                        meta: {
                            middleware: "auth",
                            role: 2
                        },
                    },
                    {
                        path: "admin/pachete",
                        component: () => import('@/views/admin/Packages'),
                        meta: {
                            middleware: "auth",
                            role: 1
                        },
                    },
                    {
                        path: "admin/pachete/new",
                        component: () => import('@/views/admin/PackageNew'),
                        meta: {
                            middleware: "auth",
                            role: 1
                        },
                    },
                    {
                        path: "admin/pachete/:id",
                        component: () => import('@/views/admin/PackageEdit'),
                        meta: {
                            middleware: "auth",
                            role: 1
                        },
                    },
                    {
                        path: "admin/users",
                        component: () => import('@/views/admin/Users'),
                        meta: {
                            middleware: "auth",
                            role: 1
                        },
                    },
                    {
                        path: "admin/users/new",
                        component: () => import('@/views/admin/UserNew'),
                        meta: {
                            middleware: "auth",
                            role: 1
                        },
                    },
                    {
                        path: "admin/users/:id",
                        component: () => import('@/views/admin/UserEdit'),
                        meta: {
                            middleware: "auth",
                            role: 1
                        },
                    },
                    {
                        path: 'client',
                        component: () => import('@/views/client/Dashboard'),
                        meta: {
                            middleware: "auth",
                            role: 3
                        },
                    },
                    {
                        path: 'client/create',
                        component: () => import('@/views/client/EventNew'),
                        meta: {
                            middleware: "auth",
                            role: 3
                        },
                    },
                    {
                        path: 'client/events/:id',
                        component: () => import('@/views/client/EventView'),
                        meta: {
                            middleware: "auth",
                            role: 3
                        }
                    },
                    {
                        path: 'client/events/:id/gallery',
                        component: () => import('@/views/client/EventGallery'),
                        meta: {
                            middleware: "auth",
                            role: 3
                        }
                    },
                ]
            }
        ]
    }
]

const router = createRouter({
    history: createWebHistory(),
    linkActiveClass: 'active',
    routes,
})

router.beforeEach((to, from, next) => {
    if (to.meta.middleware == "guest") {
        if (store.getters['auth/authenticated']) {
            if (store.getters['auth/role'] < 3) {
                next('/admin')
            }
            next('/client')
        }
        next()
    } else {
        if (store.getters['auth/authenticated']) {
            if (to.matched.some(m => m.meta.role < store.getters['auth/role'])) {
                toast({title:'403',message:'Nu esti autorizat sa accesezi aceasta pagina',type:'error', timeout:3000})
                return next('/')
            }
            next()
        } else {
            next('/autentificare')
        }
    }
})

export default router;
