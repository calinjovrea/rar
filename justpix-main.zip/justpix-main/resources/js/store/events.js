import { useCookies } from "vue3-cookies";
import router from "../router";
const { cookies } = useCookies();

export default {
    namespaced: true,
    state: {
        events_data:null,
        events: [],
        event: null,
        guest: null,
    },
    getters: {
        eventsData(state) {
            return state.events_data.data
        },
        eventsDataTotal(state) {
            return state.events_data.total
        },
        eventsDataPages(state) {
            return state.events_data.last_page
        },
        events(state) {
            return state.events
        },
        event(state) {
            return state.event
        },
        guest(state) {
            return state.guest
        },
        isGuestAuthenticated(state) {
            return state.guest && cookies.get('guest') && (cookies.get('guest') === state.guest.hash)
        },
        pics(state){
            return state.event.pics.data
        }
    },
    mutations: {
        SET_EVENTS_DATA(state, value) {
            state.events_data = value
        },
        SET_EVENTS(state, value) {
            state.events = value
        },
        SET_EVENT(state, value) {
            state.event = value
        },
        SET_GUEST(state, value) {
            state.guest = value
        },
        SET_PICS(state,value){
            value.data.forEach(
                (x) => state.event.pics.data.push(x)
            )
            state.event.pics.last_page = value.last_page
        },
        REMOVE_PIC(state, id){
            let pic = state.event.pics.data.find(x=>x.id===id)
            state.event.pics.data.splice(state.event.pics.data.indexOf(pic), 1)
        }
    },
    actions: {
        bootstrap({ commit, rootGetters }) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                window.axios.get(`/api/client/${userId}/events`).then(
                    (resp) => {
                        commit('SET_EVENTS', resp.data)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        reject(err)
                    }
                )
            })
        },
        getAllEvents({ commit }, params) {
            return new Promise((resolve, reject) => {
                window.axios.get(`/api/admin/dashboard`, {params}).then(
                    (resp) => {
                        commit('SET_EVENTS_DATA', resp.data)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        reject(err)
                    }
                )
            })
        },
        store({ commit, rootGetters }, data) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                window.axios.post(`/api/client/${userId}/events/store`, data).then((resp) => {
                    resolve(resp)
                }).catch((err) => {
                    reject(err)
                })
            }
            )
        },
        update({ commit, rootGetters }, data) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                window.axios.post(`/api/client/${userId}/events/${data.id}/update`, data).then((resp) => {
                    resolve(resp)
                }).catch((err) => {
                    reject(err)
                })
            }
            )
        },
        destroy({ commit }, id) {
            return new Promise((resolve, reject) => {
                window.axios.post(`/api/admin/packages/${id}/delete`,).then((resp) => {
                    resolve(resp)
                }).catch((err) => {
                    reject(err)
                })
            }
            )
        },
        fetch({ commit, rootGetters }, params) {
            commit('SET_EVENT', null)
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                window.axios.get(`/api/client/${userId}/events/${params.id}`).then((resp) => {
                    commit('SET_EVENT', resp.data)
                    resolve(resp)
                }).catch((err) => {
                    reject(err)
                })
            }
            )
        },
        fetchForGuest({ commit, state }, params) {
            commit('SET_EVENT', null)
            return new Promise((resolve, reject) => {
                window.axios.get(`/guest/${params.guest}/events/${params.hash}`, {params}).then((resp) => {
                    commit('SET_EVENT', resp.data)
                    if (!cookies.get('guest')){
                        commit('SET_GUEST', null)
                    }
                    if (state.guest&&state.guest.event_id!==resp.data.id){
                        cookies.remove('guest')
                        commit('SET_GUEST', null)
                    }
                    resolve(resp)
                }).catch((err) => {
                    reject(err)
                })
            }
            )
        },
        getClientPics({ commit,rootGetters }, params) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                    window.axios.get(`/api/client/${userId}/events/${params.id}/pics`, {params}).then((resp) => {
                        commit('SET_PICS', resp.data)
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        getPics({ commit }, params) {
            return new Promise((resolve, reject) => {
                    window.axios.get(`/guest/${params.guest}/events/${params.hash}/pics`, {params}).then((resp) => {
                        commit('SET_PICS', resp.data)
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        loginGuest({ commit }, data) {
            return new Promise((resolve, reject) => {
                window.axios.post(`/guest/events/${data.event_id}/login`, data).then((resp) => {
                    commit('SET_GUEST', resp.data)
                    cookies.set('guest', resp.data.hash, '7d')
                    resolve(resp)
                }).catch((err) => {
                    reject(err)
                })
            }
            )
        },
        initPayment({ commit, rootGetters }, data) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                axios.post(`/api/client/${userId}/events/${data.id}/initiate-payment`, data).then(
                    (resp) => {
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        console.log(err)
                        reject(err)
                    }
                )
            })
        },
        storePayment({ commit, rootGetters }, data) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                axios.post(`/api/client/${userId}/events/${data.event_id}/complete-payment`, data).then(
                    (resp) => {
                        commit('SET_EVENT', resp.data)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        console.log(err)
                        reject(err)
                    }
                )
            })
        },
        storeGuest({ commit, rootGetters }, data) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                axios.post(`/api/client/${userId}/events/${data.event_id}/store-guest`, data).then(
                    (resp) => {
                        commit('SET_EVENT', resp.data)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        console.log(err)
                        reject(err)
                    }
                )
            })
        },
        deleteGuest({ commit, rootGetters }, data) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                axios.post(`/api/client/${userId}/events/${data.event_id}/delete-guest`, data).then(
                    (resp) => {
                        commit('SET_EVENT', resp.data)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        console.log(err)
                        reject(err)
                    }
                )
            })
        },
        storeMessage({ commit }, data) {
            return new Promise((resolve, reject) => {
                window.axios.post(`/guest/${data.guest_hash}/events/${data.hash}/message`, data).then((resp) => {
                    resolve(resp)
                    router.push(`/events/${data.hash}`)
                }).catch((err) => {
                    reject(err)
                })
            }
            )
        },
        downloadZip({ commit }, data,) {
            return new Promise((resolve, reject) => {
                window.axios.post(`/guest/${data.guest_hash}/events/${data.hash}/zip`, data, {
                    responseType: 'blob'
                }).then((resp) => {
                    resolve(resp)
                }).catch((err) => {
                    reject(err)
                })
            }
            )
        },
        downloadClientZip({ commit, rootGetters }, data,) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                    window.axios.post(`/api/client/${userId}/events/${data.id}/zip`, data, {
                        responseType: 'blob'
                    }).then((resp) => {
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        deletePhoto({ commit, rootGetters }, obj) {
            return new Promise((resolve, reject) => {
                axios.post(`/guest/${obj.guest_hash}/media/${obj.id}/delete`).then(
                    (resp) => {
                        commit('REMOVE_PIC', obj.id)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        console.log(err)
                        reject(err)
                    }
                )
            })
        },
        deleteClientPhoto({ commit, rootGetters }, obj) {
            const userId = rootGetters['auth/user'].id
            return new Promise((resolve, reject) => {
                axios.post(`/api/client/${userId}/media/${obj.id}/delete`).then(
                    (resp) => {
                        commit('REMOVE_PIC', obj.id)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        console.log(err)
                        reject(err)
                    }
                )
            })
        }
    }
}
