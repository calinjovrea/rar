import { createStore } from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import auth from '@/store/auth'
import packages from '@/store/packages'
import users from '@/store/users'
import events from '@/store/events'

const store = createStore({
    plugins:[
        createPersistedState()
    ],
    modules:{
        auth,
        packages,
        users,
        events
    }
})

export default store
