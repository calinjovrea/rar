export default {
    namespaced: true,
    state: {
        packages: [],
        package:null
    },
    getters: {
        packages(state) {
            return state.packages
        },
        package(state) {
            return state.package
        }
    },
    mutations: {
        SET_PACKAGES(state, value) {
            state.packages = value
        },
        SET_PACKAGE(state, value) {
            state.package = value
        }
    },
    actions: {
        bootstrap({commit}) {
            return new Promise((resolve, reject) => {
                window.axios.get(`/api/admin/packages`).then(
                    (resp) => {
                        commit('SET_PACKAGES', resp.data)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        reject(err)
                    }
                )
            })
        },
        store({commit}, data) {
            return new Promise((resolve, reject) => {
                    window.axios.post('/api/admin/packages/store', data).then((resp) => {
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        update({commit}, data) {
            return new Promise((resolve, reject) => {
                    window.axios.post(`/api/admin/packages/${data.id}/update`, data).then((resp) => {
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        destroy({commit}, id) {
            return new Promise((resolve, reject) => {
                    window.axios.post(`/api/admin/packages/${id}/delete`, ).then((resp) => {
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        fetch({commit}, id) {
            return new Promise((resolve, reject) => {
                    window.axios.get(`/api/admin/packages/${id}` ).then((resp) => {
                        commit('SET_PACKAGE', resp.data)
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        }
    }
}
