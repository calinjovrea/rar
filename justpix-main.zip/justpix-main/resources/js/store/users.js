export default {
    namespaced: true,
    state: {
        users: [],
        user:null
    },
    getters: {
        users(state) {
            return state.users
        },
        user(state) {
            return state.user
        }
    },
    mutations: {
        SET_USERS(state, value) {
            state.users = value
        },
        SET_USER(state, value) {
            state.user = value
        }
    },
    actions: {
        bootstrap({commit}) {
            return new Promise((resolve, reject) => {
                window.axios.get(`/api/admin/users`).then(
                    (resp) => {
                        commit('SET_USERS', resp.data)
                        resolve(resp)
                    }
                ).catch(
                    (err) => {
                        reject(err)
                    }
                )
            })
        },
        store({commit}, data) {
            return new Promise((resolve, reject) => {
                    window.axios.post('/api/admin/users/store', data).then((resp) => {
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        update({commit}, data) {
            return new Promise((resolve, reject) => {
                    window.axios.post(`/api/admin/users/${data.id}/update`, data).then((resp) => {
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        destroy({commit}, id) {
            return new Promise((resolve, reject) => {
                    window.axios.post(`/api/admin/users/${id}/delete`, ).then((resp) => {
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        },
        fetch({commit}, id) {
            return new Promise((resolve, reject) => {
                    window.axios.get(`/api/admin/users/${id}` ).then((resp) => {
                        commit('SET_USER', resp.data)
                        resolve(resp)
                    }).catch((err) => {
                        reject(err)
                    })
                }
            )
        }
    }
}
