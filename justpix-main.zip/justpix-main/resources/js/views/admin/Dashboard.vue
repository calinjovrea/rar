<template>
    <div class="w-full px-4 md:px-12 mx-auto" v-if="dataLoaded">
        <div class="flex flex-col md:flex-row md:justify-between">
            <h1 class="uppercase text-xl md:text-center">Evenimente</h1>
            <input type="text" v-model="filters.search" class="block mb-2 border-0 border-b-1 border-slate-900 ps-0 w-full md:w-1/2 focus:ring-0 focus:border-orange-500 text-right" placeholder="Cauta eveniment sau client">
        </div>
        <section>
            <div class="flex px-2 py-1 text-sm uppercase text-white bg-slate-900">
                <div class="basis-4"></div>
                <div class="flex-2">Denumire</div>
                <div class="flex-2 hidden md:block">Data crearii</div>
                <div class="flex-2">Data evenimentului</div>
                <div class="flex-2">Pachet</div>
                <div class="flex-1 hidden md:block">Pret</div>
                <div class="flex-1">Platit</div>
                <div class="flex-2 hidden md:block">Nume Utilizator</div>
                <div class="flex-2 hidden md:block">Email</div>
                <div class="flex-2 hidden md:block">Telefon</div>

            </div>
        </section>
        <section v-if="events.length">
            <div class="flex flex-wrap px-2 py-1 text-sm odd:bg-slate-100 even:bg-white hover:bg-slate-200" v-for="event in events" :key="event.id">
                <div class="basis-4"></div>
                <div class="flex-2">{{ event.name }}</div>
                <div class="flex-2 hidden md:block">{{ formatedDate(event.created_at) }}</div>
                <div class="flex-2">{{ formatedDate(event.date) }}</div>
                <div class="flex-2">{{ event.package.name }}</div>
                <div class="flex-1 hidden md:block">{{ event.package.price / 100 }}</div>
                <div v-if="event.payments.length" class="flex-1">Da</div>
                <div v-else class="flex-1">Nu</div>
                <div class="flex-2 hidden md:block">{{ event.user.name }}</div>
                <div class="flex-2 hidden md:block">{{ event.user.email }}</div>
                <div class="flex-2 hidden md:block">{{ event.user.phone }}</div>
                <div class="basis-full h-0"></div>
                <div class="flex-1 px-2 ps-8 md:hidden">
                    <ul>
                        <li>
                            Data crearii: {{ formatedDate(event.created_at) }}
                        </li>
                        <li>
                            Pret: {{ event.package.price / 100 }} RON
                        </li>
                        <li>
                            Nume utilizator: {{ event.user.name }}
                        </li>
                        <li>
                            Email: {{ event.user.email }}
                        </li>
                        <li>
                            Telefon: {{ event.user.phone }}
                        </li>
                    </ul>
                </div>
            </div>
            <Pagination :current-page="filters.page" :total-pages="pages" :total="total" :per-page="15" @pagechanged="changePage"/>
        </section>
        <p v-else class="text-xs italic py-3">Nici un eveniment disponibil</p>
    </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import { PencilSquareIcon, TrashIcon } from '@heroicons/vue/24/outline'
import moment from "moment";
import _ from "lodash";
import Pagination from "../../components/Pagination";
export default {
    name: 'dashboard',
    components: { PencilSquareIcon, TrashIcon, Pagination },
    data() {
        return {
            dataLoaded: false,
            filters:{
                page:1,
                search:''
            }
        }
    },
    computed: {
        ...mapGetters('events', {
            events: 'eventsData',
            total:'eventsDataTotal',
            pages:'eventsDataPages'
        })
    },
    watch:{
        filters: {
            handler:'setFilters',
            deep:true
        }
    },
    notifications: {
        showSuccess: {
            title: 'Succes',
            message: 'Succes!',
            type: 'success'
        },
        showError: {
            title: 'Eroare',
            message: 'Eroare!',
            type: 'error'
        }
    },
    methods: {
        ...mapActions({
            getAllEvents: 'events/getAllEvents'
        }),
        setFilters () {
            this.searchData(this.filters,this)
        },
        searchData: _.debounce((data,vm)=>{
            vm.getAllEvents(data)
        },400),
        formatedDate(date) {
            return moment(date).format('DD MMM YYYY')
        },
        changePage(page){
            this.filters.page = page
        },
        async loadData() {
            this.getAllEvents(this.filters).then(
                (resp) => {
                    this.dataLoaded = true
                }
            ).catch(
                (err) => {
                    this.showError({ message: err.message })
                }
            )
        }
    },
    mounted() {
        this.loadData()
    }
}
</script>
