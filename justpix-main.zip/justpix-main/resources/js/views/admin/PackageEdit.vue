<template>
    <div class="max-w-screen-xl px-4 mx-auto" v-if="dataLoaded">
        <h1 class="text-center text-xl mb-12">Modifica pachet</h1>
        <div class="grid md:grid-cols-2 gap-12 mb-12">
            <div>
                <label class="text-sm">Denumire</label>
                <input type="text" placeholder="Adauga denumire"
                       class="block border-0 border-b-2 ps-0 w-full focus:ring-0 focus:border-orange-500"
                        v-model="form.name"
                >
                <div v-if="v$.form.name.required.$invalid&&v$.form.name.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
            </div>
            <div>
                <label class="text-sm">Pret</label>
                <CurrencyInput placeholder="Adauga pret" v-model="form.price" :options="{currency:'RON', precision:2, valueScaling:'precision'}"
                       class="block border-0 border-b-2 ps-0 w-full focus:ring-0 focus:border-orange-500"/>
                <div v-if="v$.form.price.required.$invalid&&v$.form.price.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
                <div v-if="v$.form.price.numeric.$invalid&&v$.form.price.$dirty" class="text-sm text-red-500">Campul trebuie sa fie numeric</div>
            </div>
        </div>
        <div class="grid md:grid-cols-2 gap-12 mb-12">
            <div>
                <label class="text-sm">Invitati min</label>
                <input type="text" placeholder="Adauga minimul de invitati"
                       class="block border-0 border-b-2 ps-0 w-full focus:ring-0 focus:border-orange-500"
                       v-model="form.min_guests"
                >
                <div v-if="v$.form.min_guests.required.$invalid&&v$.form.min_guests.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
                <div v-if="v$.form.min_guests.numeric.$invalid&&v$.form.min_guests.$dirty" class="text-sm text-red-500">Campul trebuie sa fie numeric</div>
            </div>
            <div>
                <label class="text-sm">Invitati max</label>
                <input type="text" placeholder="Adauga maximul de invitati"
                       class="block border-0 border-b-2 ps-0 w-full focus:ring-0 focus:border-orange-500"
                       v-model="form.max_guests"
                >
                <div v-if="v$.form.max_guests.required.$invalid&&v$.form.max_guests.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
                <div v-if="v$.form.max_guests.numeric.$invalid&&v$.form.max_guests.$dirty" class="text-sm text-red-500">Campul trebuie sa fie numeric</div>
            </div>
        </div>
        <div class="grid md:grid-cols-2 gap-12 mb-12">
            <div>
                <label class="text-sm">Luni</label>
                <input type="text" placeholder="Adauga valabilitate pachet in luni"
                       class="block border-0 border-b-2 ps-0 w-full focus:ring-0 focus:border-orange-500"
                       v-model="form.months"
                >
                <div v-if="v$.form.months.required.$invalid&&v$.form.months.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
                <div v-if="v$.form.months.numeric.$invalid&&v$.form.months.$dirty" class="text-sm text-red-500">Campul trebuie sa fie numeric</div>
            </div>
            <div>
                <label class="text-sm">Limita pe disk (GB)</label>
                <input type="text" placeholder="Stabileste limita maxima de upload fisiere"
                       class="block border-0 border-b-2 ps-0 w-full focus:ring-0 focus:border-orange-500"
                       v-model="form.limit"
                >
                <div v-if="v$.form.limit.numeric.$invalid&&v$.form.limit.$dirty" class="text-sm text-red-500">Campul trebuie sa fie numeric</div>
            </div>
        </div>
        <div class="grid md:grid-cols-2 gap-12">
            <div>
                <label class="text-sm block mb-3">Video</label>
                <input id="checkbox-video" type="checkbox" v-model="form.videos"
                       class="w-6 h-6 text-orange-500 bg-gray-100 border-gray-300 rounded focus:ring-orange-300 focus:ring-2">
                <label for="checkbox-video" class="ms-2 text-sm">Permite
                    adaugarea de video-uri</label>
            </div>
            <div>
                <label class="text-sm block mb-3">Popular</label>
                <input id="checkbox-features" type="checkbox" v-model="form.featured"
                       class="w-6 h-6 text-orange-500 bg-gray-100 border-gray-300 rounded focus:ring-orange-300 focus:ring-2">
                <label for="checkbox-features" class="ms-2 text-sm">Marcheaza ca popular</label>
            </div>
        </div>

        <div class="flex mt-12">
            <button :disabled="processing"
                    class="inline-block bg-orange-500 hover:bg-orange-600 py-1 px-4 mb-6 text-lg text-white rounded-full mx-auto"
                    @click="editPackage"
            >
                Modifica pachet
            </button>
        </div>

    </div>
</template>

<script>
import CurrencyInput from '@/components/CurrencyInput'
import { useVuelidate } from '@vuelidate/core'
import { required, numeric } from '@vuelidate/validators'
import { mapActions, mapGetters } from 'vuex'
export default {
    name: 'package-edit',
    components:{CurrencyInput},
    setup () {
        return {
            v$: useVuelidate()
        }
    },
    data() {
        return {
            processing: false,
            dataLoaded:false,
            form: {
                id:null,
                name: null,
                price: null,
                min_guests: null,
                max_guests: null,
                videos: false,
                months: null,
                limit:null,
                featured: false
            }

        }
    },
    validations(){
        return{
            form:{
                name:{required},
                price: {required, numeric},
                min_guests: {required, numeric},
                max_guests: {required, numeric},
                months: {required, numeric},
                limit:{numeric}
            }
        }
    },
    notifications:{
        showSuccess:{
            title:'Succes',
            message:'Pachet modificat cu succes!',
            type:'success'
        },
        showError:{
            title: 'Eroare',
            message: 'Eroare!',
            type: 'error'
        }
    },
    computed:{
        ...mapGetters('packages',{
            package:'package'
        })
    },
    methods:{
        ...mapActions({
            getPackage:'packages/fetch',
            updatePackage:'packages/update',
        }),
        async editPackage(){
            const result = await this.v$.$validate()
            if (!result) {
                return
            }
            this.processing = true
            this.updatePackage(this.form).then(
                (resp) => {
                    this.showSuccess()
                    this.$router.push('/admin/pachete')
                }
            ).catch(
                (err) =>{
                    this.showError({message:err.message})
                }
            )
        },
        async loadData(){
            this.getPackage(this.$route.params.id).then(
                (resp) =>{
                    this.form.id = this.package.id
                    this.form.name = this.package.name
                    this.form['price'] = this.package.price
                    this.form.min_guests = this.package.min_guests
                    this.form.max_guests = this.package.max_guests
                    this.form.months = this.package.months
                    this.form.limit = this.package.limit
                    this.form.videos = this.package.videos
                    this.form.featured = this.package.featured?true:false
                }
            ).catch(
                (err) => {
                    this.showError({message:err.message})
                }
            )
        }
    },
    mounted(){
        this.loadData().then(
            () => this.dataLoaded = true
        )
    }
}
</script>
