<template>
    <div class="w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto" v-if="dataLoaded">
        <div class="text-center mb-12">
            <h1 class="mb-4 text-xl">Modifica date utilizator</h1>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">1.</div>
            <div class="grow">
                <label class="font-medium block">Nume</label>
                <input
                    type="text"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 focus:ring-0 focus:border-orange-500"
                    placeholder="Adauga nume"
                    v-model="form.name"
                >
                <div v-if="v$.form.name.required.$invalid&&v$.form.name.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">2.</div>
            <div class="grow">
                <label class="font-medium block">Email</label>
                <input
                    type="email"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 focus:ring-0 focus:border-orange-500"
                    placeholder="Scrie emailul tau aici ..."
                    v-model="form.email"
                >
                <div v-if="v$.form.email.required.$invalid&&v$.form.email.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
                <div v-if="v$.form.email.email.$invalid&&v$.form.email.$dirty" class="text-sm text-red-500">Campul nu este email</div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">3.</div>
            <div class="grow">
                <label class="font-medium block">Rol</label>
                <v-select
                    id="sel"
                    v-model="form.role"
                    :options="roles"
                    :reduce="op => op.id"
                    label="role"
                    placeholder="Alege rolul"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 focus:ring-0"
                />
                <div v-if="v$.form.role.required.$invalid&&v$.form.role.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
            </div>
        </div>
        <div class="flex">
            <div class="basis-12"></div>
            <button :disabled="processing" class="bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full" @click="editUser">Modifica utilizator</button>
        </div>
    </div>
</template>
<script>
import {useVuelidate} from "@vuelidate/core";
import { required, email } from '@vuelidate/validators'
import { mapActions, mapGetters } from 'vuex'

export default {
    name:'user-edit',
    setup () {
        return {
            v$: useVuelidate()
        }
    },
    data(){
        return{
            processing:false,
            dataLoaded:false,
            form:{
                id:null,
                name:null,
                email:null,
                role:null
            },
            roles:[
                {id:1, role:'Superadmin'},
                {id:2, role:'Admin'}
            ]
        }
    },
    validations(){
        return{
            form:{
                name:{required},
                email:{required, email},
                role:{required}
            }
        }
    },
    notifications:{
        showSuccess:{
            title:'Succes',
            message:'Utilizator modificat cu succes!',
            type:'success'
        },
        showError:{
            title: 'Eroare',
            message: 'Erori de validare',
            type: 'error'
        }
    },
    computed:{
        ...mapGetters('users',{
            user:'user'
        })
    },
    methods:{
        ...mapActions({
            getUser:'users/fetch',
            updateUser:'users/update'
        }),
        async editUser(){
            const result = await this.v$.$validate()
            if (!result) {
                return
            }
            this.processing = true
            this.updateUser(this.form).then(
                (resp) => {
                    this.showSuccess()
                    this.$router.push('/admin/users')
                }
            ).catch(
                (err) =>{
                    this.showError({message:err.message})
                }
            )
        },
        async loadData(){
            this.getUser(this.$route.params.id).then(
                (resp) =>{
                    this.form.id = this.user.id
                    this.form.name = this.user.name
                    this.form.email = this.user.email
                    this.form.role = this.user.role
                }
            ).catch(
                (err) => {
                    this.showError({message:err.message})
                }
            )
        }
    },
    mounted(){
        this.loadData().then(
            () => this.dataLoaded = true
        )
    }
}
</script>
