<template>
    <div class="w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto">
        <div class="text-center mb-12">
            <h1 class="mb-4 text-xl">Adauga utilizator nou</h1>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">1.</div>
            <div class="grow">
                <label class="font-medium block">Nume</label>
                <input
                    type="text"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 focus:ring-0 focus:border-orange-500"
                    placeholder="Adauga nume"
                    v-model="form.name"
                >
                <div v-if="v$.form.name.required.$invalid&&v$.form.name.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">2.</div>
            <div class="grow">
                <label class="font-medium block">Email</label>
                <input
                    type="email"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 focus:ring-0 focus:border-orange-500"
                    placeholder="Scrie emailul tau aici ..."
                    v-model="form.email"
                >
                <div v-if="v$.form.email.required.$invalid&&v$.form.email.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
                <div v-if="v$.form.email.email.$invalid&&v$.form.email.$dirty" class="text-sm text-red-500">Campul nu este email</div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">3.</div>
            <div class="grow">
                <label class="font-medium block">Rol</label>
                <v-select
                    id="sel"
                    v-model="form.role"
                    :options="roles"
                    :reduce="op => op.id"
                    label="role"
                    placeholder="Alege rolul"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 focus:ring-0"
                />
                <div v-if="v$.form.role.required.$invalid&&v$.form.role.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
            </div>
        </div>
        <div class="flex">
            <div class="basis-12"></div>
            <button :disabled="processing" class="bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full" @click="createUser">Adauga utilizator</button>
        </div>
    </div>
</template>
<script>
import {useVuelidate} from "@vuelidate/core";
import { required, email } from '@vuelidate/validators'
import { mapActions, mapGetters } from 'vuex'

export default {
    name:'register',
    setup () {
        return {
            v$: useVuelidate()
        }
    },
    data(){
        return{
            processing:false,
            form:{
                name:null,
                email:null,
                role:null
            },
            roles:[
                {id:1, role:'Superadmin'},
                {id:2, role:'Admin'}
            ]
        }
    },
    validations(){
        return{
            form:{
                name:{required},
                email:{required, email},
                role:{required}
            }
        }
    },
    notifications:{
        showSuccess:{
            title:'Succes',
            message:'Utilizator creat cu succes!',
            type:'success'
        },
        showError:{
            title: 'Eroare',
            message: 'Erori de validare',
            type: 'error'
        }
    },
    methods:{
        ...mapActions({
            storeUser:'users/store'
        }),
        async createUser(){
            const result = await this.v$.$validate()
            if (!result) {
                return
            }
            this.processing = true
            this.storeUser(this.form).then(
                (resp) => {
                    this.showSuccess()
                    this.$router.push('/admin/users')
                }
            ).catch(
                (err) =>{
                    this.showError({message:err.message})
                }
            )
        }
    }
}
</script>
