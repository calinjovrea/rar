<template>
    <div class="w-full px-4 md:px-12 mx-auto" v-if="dataLoaded">
        <router-link to="/admin/users/new" class="inline-block bg-orange-500 hover:bg-orange-600 py-1 px-2 mb-6 text-sm text-white rounded-full">Adauga utilizator</router-link>
        <section>
            <div class="flex px-2 py-1 text-sm uppercase text-white bg-slate-900">
                <div class="basis-4"></div>
                <div class="flex-2">Nume</div>
                <div class="flex-1">Email</div>
                <div class="flex-1">Rol</div>
                <div class="basis-12"></div>
            </div>
        </section>
        <section v-if="users.length">
            <div class="flex px-2 py-1 text-sm odd:bg-slate-100 even:bg-white hover:bg-slate-200" v-for="user in users" :key="user.id">
                <div class="basis-4"></div>
                <div class="flex-2">{{ user.name }}</div>
                <div class="flex-1">{{ user.email }}</div>
                <div class="flex-1">{{role(user)}}</div>
                <div class="basis-12 flex justify-end">
                    <router-link :to="`/admin/users/${user.id}`">
                        <PencilSquareIcon class="h-5 w-4 text-yellow-400 hover:text-yellow-500" />
                    </router-link>
                    <button class="ml-2" @click="deleteUser(user.id)" v-if="user.role!==1">
                        <TrashIcon class="h-4 w-4 text-red-500 hover:text-red-600" />
                    </button>
                </div>
            </div>
        </section>
        <p v-else class="text-xs italic py-3">Nici un utilizator adaugat</p>
    </div>
</template>

<script>
import {mapActions, mapGetters} from "vuex";
import { PencilSquareIcon, TrashIcon } from '@heroicons/vue/24/outline'

export default {
    name:'users',
    components:{PencilSquareIcon ,TrashIcon},
    data(){
        return{
            dataLoaded:false,
            roles:[
                {id:1, role:'Superadmin'},
                {id:2, role:'Admin'}
            ]
        }
    },
    notifications:{
        showSuccess:{
            title:'Succes',
            message:'Succes!',
            type:'success'
        },
        showError:{
            title: 'Eroare',
            message: 'Eroare!',
            type: 'error'
        }
    },
    computed:{
        ...mapGetters('users',{
            users:'users'
        })
    },
    methods:{
        ...mapActions({
            boostrap:'users/bootstrap',
            destroyUser:'users/destroy'
        }),
        role(user){
            return this.roles.find(x=>x.id===user.role).role
        },
        deleteUser(id){
            this.$swal({
                type:'confirm',
                icon: 'warning',
                title: `Sterge Utilizatorul`,
                text: `Esti sigur ca vrei sa stergi utilizatorul?`,
                confirmButtonText:'Accept',
                showCancelButton:true,
                cancelButtonText:'Anuleaza',
            }).then(
                (result) => {
                    if (result.value){
                        this.destroyUser(id).then(
                            (resp) => {
                                this.showSuccess({message:'Utilizatorul a fost sters cu succes!'})
                                this.loadData()
                            }
                        ).catch(
                            (err) => {
                                this.showError({message: err.message})
                            }
                        )
                    }
                }
            )
        },
        async loadData(){
            this.boostrap().then(
                (resp) => {
                    this.dataLoaded = true
                }
            ).catch(
                (err) => {
                    this.showError({message:err.message})
                }
            )
        }
    },
    mounted() {
        this.loadData()
    }
}
</script>
