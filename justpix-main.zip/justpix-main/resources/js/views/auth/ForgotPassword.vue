<template>
    <div class="w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto bg-white rounded-xl shadow-lg">
        <div class="text-center mb-12">
            <h1 class="mb-4 text-4xl">Reseteaza parola</h1>
            <p>Introdu adresa de email si vei primi pe adresa ta de email un link de resetare a parolei. Linkul este activ timp de 60 de minute.</p>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">1.</div>
            <div class="grow">
                <label class="font-medium block">Email<span class="text-red-500 font-semibold">*</span></label>
                <input type="email"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Scrie emailul tau aici ..." v-model="form.email">
                <div v-if="v$.form.email.required.$invalid && v$.form.email.$dirty" class="text-sm text-red-500">Campul e
                    obligatoriu</div>
                <div v-if="v$.form.email.email.$invalid && v$.form.email.$dirty" class="text-sm text-red-500">Campul nu este
                    email</div>
            </div>
        </div>
        <div class="flex">
            <div class="basis-12"></div>
            <div class="grow">
            <button :disabled="processing"
                class="bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full mb-12"
                @click="submitForgot">Trimite link de resetare</button>
            <p class="text-center"><router-link to="/autentificare" class="text-orange-500 cursor-pointer">Inapoi la autentificare</router-link></p>
            </div>
        </div>
    </div>
</template>
<script>
import { useVuelidate } from "@vuelidate/core";
import {required, email, sameAs, minLength, numeric} from '@vuelidate/validators'
import { mapActions, mapGetters } from 'vuex'

export default {
    name: 'register',
    setup() {
        return {
            v$: useVuelidate()
        }
    },
    data() {
        return {
            processing: false,
            form: {
                email: null
            }
        }
    },
    validations() {
        return {
            form: {
                email: { required, email },
            }
        }
    },
    notifications: {
        showSuccess: {
            title: 'Succes',
            message: 'Link-ul a fost trimis cu succes!',
            type: 'success'
        },
        showError: {
            title: 'Eroare',
            message: 'Erori de validare',
            type: 'error'
        }
    },
    methods: {
        async submitForgot() {
            const result = await this.v$.form.$validate()
            if (!result) {
                return
            }
            this.processing = true
            await axios.get('/sanctum/csrf-cookie')
            await axios.post('/password/email', this.form).then(response => {
                this.showSuccess()
                this.$router.push('/autentificare')
            }).catch(({ response }) => {
                this.showError({ message: response.message })
            }).finally(() => {
                this.processing = false
            })
        }
    }
}
</script>
