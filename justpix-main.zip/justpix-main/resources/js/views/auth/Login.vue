<template>
    <div class="w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto bg-white rounded-xl shadow-lg">
        <div class="text-center mb-12">
            <h1 class="mb-4 text-4xl">Intra in cont</h1>
            <p>Multumim ca ati ales JustPix. Introduceti adresa de email si parola.</p>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">1.</div>
            <div class="grow">
                <label class="font-medium block">Email</label>
                <input type="email"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Scrie emailul tau aici ..." v-model="form.email">
                <div v-if="v$.form.email.required.$invalid && v$.form.email.$dirty" class="text-sm text-red-500">Campul e
                    obligatoriu</div>
                <div v-if="v$.form.email.email.$invalid && v$.form.email.$dirty" class="text-sm text-red-500">Campul nu este
                    email</div>
            </div>
        </div>
        <div class="flex mb-16">
            <div class="basis-12">2.</div>
            <div class="grow">
                <label class="font-medium block">Parola</label>
                <input type="password"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Scrie parola ta aici ..." v-model="form.password">
                <div v-if="v$.form.password.required.$invalid && v$.form.password.$dirty" class="text-sm text-red-500">Campul
                    e obligatoriu</div>
            </div>
        </div>
        <div class="flex">
            <div class="basis-12"></div>
            <div class="grow">
                <button :disabled="processing"
                        class="bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full mb-12"
                        @click="localLogin">Autentificare</button>
                <p class="text-center"><router-link to="/forgot-password" class="text-orange-500 cursor-pointer">Am uitat parola</router-link></p>
            </div>
        </div>
    </div>
</template>

<script>
import { useVuelidate } from '@vuelidate/core'
import { required, email } from '@vuelidate/validators'
import { mapActions, mapGetters } from 'vuex'
export default {
    name: 'login',
    setup() {
        return {
            v$: useVuelidate()
        }
    },
    data() {
        return {
            processing: false,
            form: {
                email: null,
                password: null
            }
        }
    },
    validations() {
        return {
            form: {
                email: { required, email },
                password: { required }
            }
        }
    },
    notifications: {
        showSuccess: {
            title: 'Succes',
            message: 'Autentificare reusita!',
            type: 'success'
        },
        showError: {
            title: 'Eroare',
            message: 'Date autentificare incorecte!',
            type: 'error'
        }
    },
    computed: {
        ...mapGetters('auth', {
            user: 'user'
        })
    },
    methods: {
        ...mapActions({
            login: 'auth/login'
        }),
        async localLogin() {
            const result = await this.v$.$validate()
            if (!result) {
                return
            }
            this.processing = true
            await axios.get('/sanctum/csrf-cookie')
            await axios.post('/login', this.form).then(({ data }) => {
                this.login().then(
                    () => this.showSuccess()
                )
            }).catch(({ response }) => {
                if (response.status === 422) {
                    this.showError()
                } else {
                    this.showError({ message: response.data.message })
                }
            }).finally(() => {
                this.processing = false
            })
        }
    },
    mounted() {

    }
}
</script>
