<template>
    <div class="w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto bg-white rounded-xl shadow-lg">
        <div class="text-center mb-12">
            <h1 class="mb-4 text-4xl">Creaza un cont</h1>
            <p>Multumim ca ati ales JustPix, pentru a incepe creati un cont.</p>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">1.</div>
            <div class="grow">
                <label class="font-medium block">Numele complet<span class="text-red-500 font-semibold">*</span></label>
                <input type="text"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Scrie numele tau aici ..." v-model="form.name">
                <div v-if="v$.form.name.required.$invalid && v$.form.name.$dirty" class="text-sm text-red-500">Campul e
                    obligatoriu</div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">2.</div>
            <div class="grow">
                <label class="font-medium block">Email<span class="text-red-500 font-semibold">*</span></label>
                <input type="email"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Scrie emailul tau aici ..." v-model="form.email">
                <div v-if="v$.form.email.required.$invalid && v$.form.email.$dirty" class="text-sm text-red-500">Campul e
                    obligatoriu</div>
                <div v-if="v$.form.email.email.$invalid && v$.form.email.$dirty" class="text-sm text-red-500">Campul nu este
                    email</div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">3.</div>
            <div class="grow">
                <label class="font-medium block">Telefon</label>
                <input type="text"
                       class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                       placeholder="Scrie telefonul tau aici ..." v-model="form.phone">
                <div v-if="v$.form.phone.numeric.$invalid&&v$.form.phone.$dirty" class="text-sm text-red-500">Campul trebuie sa fie numeric</div>
                <div v-if="v$.form.phone.minLength.$invalid&&v$.form.phone.$dirty" class="text-sm text-red-500">Campul trebuie sa contina minim 10 cifre</div>
            </div>
        </div>
        <div class="flex mb-16">
            <div class="basis-12">4.</div>
            <div class="grow">
                <label class="font-medium block">Parola<span class="text-red-500 font-semibold">*</span></label>
                <input type="password"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Scrie parola ta aici ..." v-model="form.password">
                <div v-if="v$.form.password.required.$invalid && v$.form.password.$dirty" class="text-sm text-red-500">Campul
                    e obligatoriu</div>
                <div v-if="v$.form.password.minLength.$invalid&&v$.form.password.$dirty" class="text-sm text-red-500">Campul trebuie sa contina minim 8 caractere</div>
            </div>
        </div>
        <div class="flex mb-16">
            <div class="basis-12">5.</div>
            <div class="grow">
                <label class="font-medium block">Confirma parola<span class="text-red-500 font-semibold">*</span></label>
                <input type="password"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Confirma parola ta aici ..." v-model="form.password_confirmation">
                <div v-if="v$.form.password_confirmation.samePassword.$invalid && v$.form.password_confirmation.$dirty"
                    class="text-sm text-red-500">Parolele nu coincid</div>
            </div>
        </div>
        <div class="flex">
            <div class="basis-12"></div>
            <button :disabled="processing"
                class="bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full mb-12"
                @click="register">Creaza contul</button>
        </div>
    </div>
</template>
<script>
import { useVuelidate } from "@vuelidate/core";
import {required, email, sameAs, minLength, numeric} from '@vuelidate/validators'
import { mapActions, mapGetters } from 'vuex'

export default {
    name: 'register',
    setup() {
        return {
            v$: useVuelidate()
        }
    },
    data() {
        return {
            processing: false,
            form: {
                name: null,
                email: null,
                phone:null,
                password: null,
                password_confirmation: null
            }
        }
    },
    validations() {
        return {
            form: {
                name: { required },
                email: { required, email },
                password: { required,minLength:minLength(8) },
                password_confirmation: { samePassword: sameAs(this.form.password) },
                phone:{numeric, minLength:minLength(10)}
            }
        }
    },
    notifications: {
        showSuccess: {
            title: 'Succes',
            message: 'Cont creat cu succes!',
            type: 'success'
        },
        showError: {
            title: 'Eroare',
            message: 'Erori de validare',
            type: 'error'
        }
    },
    methods: {
        ...mapActions({
            signIn: 'auth/login'
        }),
        async register() {
            const result = await this.v$.form.$validate()
            if (!result) {
                return
            }
            this.processing = true
            await axios.get('/sanctum/csrf-cookie')
            await axios.post('/register', this.form).then(response => {
                this.signIn().then(
                    () => this.showSuccess()
                )
            }).catch(({ response }) => {
                if (response.status === 422) {
                    this.showError()
                } else {
                    this.showError({ message: response.data.message })
                }
            }).finally(() => {
                this.processing = false
            })
        }
    }
}
</script>
