<template>
    <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl shadow-lg flex flex-col">
        <h1 class="mb-4 text-4xl">Salut {{ user.name }}!</h1>
        <section v-if="dataLoaded">
            <div v-if="events.length">
                <div v-for="event in events" :key="event.id" class="mb-12 text-2xl">
                    <router-link :to="`/client/events/${event.id}`">~ {{ event.name }}</router-link>
                </div>
            </div>
            <h3 v-else class="mb-12">Nu ai creat nici un eveniment</h3>
            <router-link to="/client/create"
                class="bg-orange-500 hover:bg-orange-600 text-white text-xl py-2 px-4 mb-4 rounded-full">Creaza
                eveniment</router-link>
        </section>
    </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";

export default {
    name: 'client-dashboard',
    data() {
        return {
            dataLoaded: false,
        }
    },
    computed: {
        ...mapGetters('auth', {
            user: 'user'
        }),
        ...mapGetters('events', {
            events: 'events'
        }),
    },
    methods: {
        ...mapActions({
            bootstrap: 'events/bootstrap'
        }),
        async loadData() {
            this.bootstrap().then(
                (resp) => {
                    this.dataLoaded = true
                }
            ).catch(
                (err) => {
                    this.showError({ message: err.message })
                }
            )
        }
    },
    mounted() {
        this.loadData()
    }
}
</script>
