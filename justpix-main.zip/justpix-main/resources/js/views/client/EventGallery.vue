<template>
    <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg flex" v-if="dataLoaded">
        <router-link :to="`/client/events/${event.id}`" class="text-slate-900 bg-white px-3 py-1 text-sm rounded-full border border-slate-900 border-solid border-1 hover:text-white hover:bg-slate-900">
            <ArrowUturnLeftIcon class="w-6 h-6"/>
        </router-link>
        <h1 class="text-center text-lg w-full">{{ event.name }}</h1>
    </div>
    <div v-if="dataLoaded">
        <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg" v-if="pics.length">
            <h3>Poze incarcate:</h3>
            <div class="flex my-5 space-x-2 md:space-x-4">
                <button @click="toggleSelectable" :class="selectable ? 'text-white bg-orange-700' : 'text-orange-500 bg-white'"
                    class="px-3 py-1 text-sm rounded-full border border-orange-500 border-solid border-1 hover:text-white hover:bg-orange-500">
                    Selecteaza
                </button>
                <button @click="slideShow = !slideShow" :class="slideShow ? 'text-white bg-orange-700' : 'text-orange-500 bg-white'"
                    class=" px-3 py-1 text-sm rounded-full border border-orange-500 border-solid border-1 hover:text-white hover:bg-orange-500">
                    Slideshow
                </button>
                <button @click="tryDownloadZip"
                    class="px-3 py-1 text-sm text-orange-500 rounded-full bg-white border border-orange-500 border-solid border-1 hover:text-white hover:bg-orange-500">
                    Download zip
                </button>
            </div>
            <div v-if="!slideShow">
                <div  class="columns-2 md:columns-3 lg:columns-4 gap-3">
                    <div class="relative overflow-hidden w-full flex items-center justify-center rounded mb-2"
                         v-for="image in pics" :key="image.id" @click="selectPhoto(image)"
                         :class="isSelected(image) ? 'border border-orange-500 border-2' : ''">
                        <a v-if="!selectable" :href="`/storage/${image.id}/${image.file_name}`" download
                           class="absolute top-2 left-2 z-10">
                            <CloudArrowDownIcon
                                class="bg-orange-600 text-white rounded-full hover:bg-orange-700 w-6 h-6 p-1 z-10">
                            </CloudArrowDownIcon>
                        </a>
                        <TrashIcon @click="tryDeletePhoto(image.id)"
                                   class="absolute top-2 right-2 bg-white text-red-500 rounded-full hover:bg-slate-100 w-4 h-4 md:w-6 md:h-6 p-1 z-10">
                        </TrashIcon>
                        <div v-if="isImage(image)">
                            <img :src="`${image.original_url}`" alt="">
                        </div>
                        <div v-else>
                            <video controls>
                                <source :src="`${image.original_url}`" :type="image.mime_type">
                            </video>
                        </div>
                    </div>
                </div>
                <div class="flex">
                    <button class="text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 text-center mx-auto my-12" v-if="filters.page < event.pics.last_page" @click="loadMore()">Arata mai multe</button>
                </div>
            </div>
            <div v-else>
                <carousel :wrap-around="true" class="rounded">
                    <slide v-for="image in slideImages" :key="image.id">
                        <img :src="`${image.original_url}`" alt="">
                    </slide>
                    <template #addons>
                        <navigation />
                    </template>
                </carousel>
            </div>
        </div>
        <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg" v-else>
            Nici o poza adaugata
        </div>
    </div>
</template>
<script>
import { mapActions, mapGetters } from "vuex";
import { required, numeric, minLength, maxLength } from '@vuelidate/validators'
import { useVuelidate } from "@vuelidate/core";
import moment from "moment";
import 'vue3-carousel/dist/carousel.css'
import { Carousel, Slide, Navigation } from 'vue3-carousel'
import {
    CloudArrowDownIcon,
    TrashIcon,
    ArrowUturnLeftIcon
} from '@heroicons/vue/24/outline'
export default {
    name: 'event-gallery',
    setup() {
        return {
            v$: useVuelidate()
        }
    },
    components: {
        CloudArrowDownIcon,
        TrashIcon,
        ArrowUturnLeftIcon,
        Carousel,
        Slide,
        Navigation,
    },
    data() {
        return {
            dataLoaded: false,
            selectable: false,
            selected: [],
            slideShow: false,
            filters:{
                page:1
            }
        }
    },
    notifications: {
        showSuccess: {
            title: 'Succes',
            message: 'Ai intrat cu succes in pagina evenimentului!',
            type: 'success'
        },
        showError: {
            title: 'Eroare',
            message: 'Eroare!',
            type: 'error'
        }
    },
    computed: {
        ...mapGetters('events', {
            event: 'event',
            pics: 'pics',
        }),
        slideImages() {
            return this.selected.length ? this.selected : this.pics
        }

    },
    methods: {
        ...mapActions({
            getEvent: 'events/fetch',
            deletePhoto: 'events/deleteClientPhoto',
            downloadZip: 'events/downloadClientZip',
            getPics: 'events/getClientPics'
        }),
        isImage(image){
            return image.mime_type.includes('image')
        },
        loadMore(){
            this.filters.page +=1
            let params = {
                id:this.$route.params.id,
                page:this.filters.page
            }
            this.getPics(params).then(
                (resp) => true
            ).catch(
                (err) => {
                    this.showError({message: err.message})
                    this.filters.page -=1
                }
            )
        },
        toggleSelectable() {
            if (this.slideShow) {
                this.slideShow = false
            }
            this.selectable = !this.selectable
            this.selected = []
        },
        isSelected(image) {
            return this.selected.find(x => x === image)
        },
        selectPhoto(image) {
            if (this.selectable) {
                if (this.isSelected(image)) {
                    this.selected.splice(this.selected.indexOf(image), 1)
                } else {
                    this.selected.push(image)
                }
            }
        },
        tryDownloadZip() {
            let obj = {
                id: this.event.id,
                images: []
            }
            if (this.selected.length) {
                obj.images = this.selected.map(x => x.id)
            } else {
                obj.images = this.pics.map(x => x.id)
            }
            this.downloadZip(obj).then(
                (resp) => {
                    let name = this.event.name.replaceAll(' ', '_')
                    let fileName = name+'_'+moment().format('DD_MM_YYYY')+'.zip'
                    let blob=new Blob([resp.data]);
                    let link=document.createElement('a');
                    link.href=window.URL.createObjectURL(blob);
                    link.download=fileName;
                    link.click();
                    this.showSuccess({message:"Arhiva descarcata cu succes"})
                }
            )
        },
        async loadData() {
            let params = {
                id:this.$route.params.id,
                page:this.filters.page,
            }
            this.getEvent(params).then(
                (resp) => this.dataLoaded = true
            ).catch(
                (err) => this.showError({ message: err.message })
            )
        },
        tryDeletePhoto(id) {
            this.$swal({
                type: 'confirm',
                icon: 'warning',
                title: `Sterge Poza`,
                text: `Esti sigur ca vrei sa stergi poza?`,
                confirmButtonText: 'Accept',
                showCancelButton: true,
                cancelButtonText: 'Anuleaza',
            }).then(
                (result) => {
                    if (result.value) {
                        let obj = {
                            id: id
                        }
                        this.deletePhoto(obj).then(
                            (resp) => {
                                this.showSuccess({ message: 'Poza a fost stearsa cu succes!' })
                            }
                        ).catch(
                            (err) => {
                                this.showError({ message: err.message })
                            }
                        )
                    }
                }
            )
        },
    },
    mounted() {
        this.loadData()
    }

}
</script>

<style>
.carousel__prev, .carousel__next {
    @apply bg-white rounded-full
}
</style>
