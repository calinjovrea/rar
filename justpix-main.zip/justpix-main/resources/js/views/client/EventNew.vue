<template>
    <section class="w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto bg-white rounded-xl shadow-lg" v-if="dataLoaded">
        <div class="text-center mb-12">
            <h1 class="mb-4 text-4xl">Creaza un eveniment nou</h1>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">1.</div>
            <div class="grow">
                <label class="font-medium block">Denumirea evenimentului <span class="text-red-500 font-semibold">*</span></label>
                <input
                    type="text"
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Scrie denumirea evenimentului tau aici ..."
                    v-model="form.name"
                >
                <div v-if="v$.form.name.required.$invalid&&v$.form.name.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">2.</div>
            <div class="grow">
                <label class="font-medium block">Mesaj de bun venit</label>
                <textarea
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Scrie mesajul pe care il vor vedea invitatii ..."
                    v-model="form.welcome"
                ></textarea>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">3.</div>
            <div class="grow">
                <label class="font-medium block mb-2">Imaginea de profil a evenimentului</label>
                <vue-dropzone
                    :multiple="false"
                    accept="image/*"
                    :max-files="1"
                    url="/api/client/single-upload"
                    @filesUploaded="setFiles"
                    @filesErrors="showFilesErrors"
                    @uploadError="showUploadError"
                    v-if="!form.featured"
                ></vue-dropzone>
                <div v-else class="w-full overflow-hidden max-h-48 mt-2 border rounded-xl flex flex-col justify-center items-center text-center relative">
                    <img :src="form.featured.url" alt="" class="w-full">
                    <div class="h-8 w-8 rounded-full absolute top-4 right-4 bg-white z-10 hover:bg-slate-800 group cursor-pointer" @click="form.featured = null">
                        <div class="flex w-full h-full justify-center items-center">
                            <trash-icon  class="w-6 h-6 text-red-500 group-hover:text-white"></trash-icon>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">4.</div>
            <div class="grow">
                <label class="font-medium block">Data evenimentului <span class="text-red-500 font-semibold">*</span></label>
                <VueDatePicker
                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                    placeholder="Adauga data evenimentului ..."
                    v-model="form.date"
                    :auto-apply="true"
                    :enable-time-picker="false"
                    format="dd-MM-yyyy"
                    model-type="yyyy-MM-dd"
                    :min-date="now"
                    :month-change-on-scroll="false"
                ></VueDatePicker>
                <div v-if="v$.form.date.required.$invalid&&v$.form.date.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">5.</div>
            <div class="grow">
                <div class="mb-2">
                    <label class="font-medium block mb-3">Evenimentul necesita PIN</label>
                    <input id="checkbox-video" type="checkbox" v-model="form.has_pin"
                           class="w-6 h-6 text-orange-500 bg-gray-100 border-gray-300 rounded focus:ring-orange-300 focus:ring-2" @input="form.pin=null">
                    <label for="checkbox-video" class="ms-2 text-sm">Foloseste PIN</label>
                </div>
                <div v-if="form.has_pin">
                    <label class="font-medium block">PIN-ul evenimentului (4 cifre) <span class="text-red-500 font-semibold">*</span></label>
                    <input
                        type="text"
                        class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                        placeholder="Seteaza PIN-ul evenimentului ..."
                        v-model="form.pin"
                    >
                    <div v-if="v$.form.pin.required.$invalid&&v$.form.pin.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
                    <div v-if="v$.form.pin.numeric.$invalid&&v$.form.pin.$dirty" class="text-sm text-red-500">Campul trebuie sa fie numeric</div>
                    <div v-if="v$.form.pin.minLength.$invalid&&v$.form.pin.$dirty" class="text-sm text-red-500">Campul trebuie sa contina 4 cifre</div>
                    <div v-if="v$.form.pin.maxLength.$invalid&&v$.form.pin.$dirty" class="text-sm text-red-500">Campul trebuie sa contina 4 cifre</div>
                </div>
            </div>
        </div>
        <div class="flex mb-12">
            <div class="basis-12">6.</div>
            <div class="grow">
                <label class="font-medium block">Pachetul dorit <span class="text-red-500 font-semibold">*</span></label>
                <v-select
                    id="sel"
                    v-model="form.package_id"
                    :options="packages"
                    :reduce="op => op.id"
                    label="name"
                    placeholder="Alege pachetul ..."
                    class="frontend mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                >
                    <template #option="{name,min_guests,max_guests,limit,price,videos}">
                        <span class="font-semibold">{{name}}</span> | <span>{{min_guests}} - {{max_guests}} Invitati | Foto {{videos?'& Video':''}} | {{limit?'Maxim '+limit+'GB upload':'Fara limita de upload'}} | {{inRon(price)}}</span>
                    </template>
                    <template #selected-option="{name,min_guests,max_guests,limit,price,videos}">
                        <span class="font-semibold pe-2">{{name}}</span> | <span class="ps-2">{{min_guests}} - {{max_guests}} Invitati | Foto {{videos?'& Video':''}} | {{limit?'Maxim '+limit+'GB upload':'Fara limita de upload'}} | {{inRon(price)}}</span>
                    </template>
                    <template #no-options="{}">
                        Nici un pachet gasit...
                    </template>
                </v-select>
                <div v-if="v$.form.package_id.required.$invalid&&v$.form.package_id.$dirty" class="text-sm text-red-500">Campul e obligatoriu</div>
            </div>
        </div>
        <div class="flex">
            <div class="basis-12"></div>
            <button :disabled="processing" class="bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full mb-12" @click="createEvent">Creaza eveniment</button>
        </div>
    </section>
</template>

<script>
import { useVuelidate } from '@vuelidate/core'
import { required, numeric, minLength, maxLength, requiredIf } from '@vuelidate/validators'
import { mapActions, mapGetters } from 'vuex'
import moment from 'moment'
import VueDropzone from "../../components/VueDropzone";
import {TrashIcon} from '@heroicons/vue/24/outline'
export default {
    name:'event-new',
    components: {VueDropzone, TrashIcon},
    setup () {
        return {
            v$: useVuelidate()
        }
    },
    data(){
        return{
            processing:false,
            dataLoaded:false,
            form:{
                name:null,
                welcome:null,
                date:null,
                package_id: null,
                has_pin:false,
                pin:null,
                featured:null
            }
        }
    },
    validations(){
        return{
            form:{
                name:{required},
                date:{required},
                package_id:{required},
                pin:{required : requiredIf(this.form.has_pin), numeric, minLength:minLength(4), maxLength:maxLength(4)}
            }
        }
    },
    notifications:{
        showSuccess:{
            title:'Succes',
            message:'Eveniment creat cu succes!',
            type:'success'
        },
        showError:{
            title: 'Eroare',
            message: 'Eroare!',
            type: 'error'
        }
    },
    computed:{
        ...mapGetters('packages',{
            packages:'packages'
        }),
        now(){
           return moment().format()
        }
    },
    methods:{
        ...mapActions({
            getPackages:'packages/bootstrap',
        }),
        ...mapActions({
            storeEvent:'events/store',
        }),
        inRon(value){
            return 'RON '+value/100
        },
        setFiles(response){
            this.form.featured = response.data
            this.showSuccess({message:'Imagine adaugata cu succes'})
        },
        showFilesErrors(data){
            console.log(data)
            data.forEach(
                (x) => {
                    this.showError({message:x.file?x.file.name+':'+x.errors[0].message:x.errors[0].message})
                }
            )
        },
        showUploadError(error){
            this.showError({message:error.message})
        },
        async createEvent(){
            const result = await this.v$.$validate()
            if (!result) {
                return
            }
            this.processing = true
            let form = {...this.form}
            form.date = moment(this.form.date).format('YYYY-MM-DD')
            this.storeEvent(form).then(
                (resp) => {
                    this.showSuccess()
                    this.$router.push('/client')
                }
            ).catch(
                (err) =>{
                    this.showError({message:err.message})
                }
            ).finally(
                this.processing = false
            )
        },
        async loadData(){
            this.getPackages().then(
                (resp) => {
                    this.dataLoaded = true
                }
            ).catch(
                (err) => {
                    this.showError({message:err.message})
                }
            )
        }
    },
    mounted() {
        this.loadData()
    }
}
</script>
