<template>
    <div v-if="dataLoaded">
        <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 flex shadow-lg">
            <div class="basis-12">
                <button @click="toggleInput('name')">
                    <CheckCircleIcon class="h-8 w-6 text-green-500" v-if="!!event.payment" />
                    <MinusCircleIcon class="h-8 w-6 text-red-500" v-else />
                </button>
            </div>
            <div>
                <h3 class="text-2xl">Statusul evenimentului ~ <span
                        class="italic">{{ !!event.payment ? 'activ' : 'in asteptarea platii' }}</span></h3>
                <div v-if="!!event.payment">
                    <h4 class="mb-4 text-xl">{{ event.package.name }} | {{ event.package.min_guests }} -
                        {{ event.package.max_guests }} Invitati | Foto {{event.package.videos?'& Video':''}} |
                        {{
                            event.package.limit ? 'Maxim ' + event.package.limit + 'GB upload' : 'Fara limita de upload'
                        }}
                    </h4>
                    <p class="mt-4 mb-4 text-slate-400">
                        Evenimentul tau este activ. Poti sa descarci codul QR, sa adaugi invitati si sa trimiti acestora
                        linkul evenimentului.
                    </p>
                </div>
                <div class="mt-4 mb-4" v-else>
                    <p class="text-slate-400">
                        Evenimentul nu este inca activ. Dupa efectuarea platii acesta va fi activat automat.
                    </p>
                    <p class="text-slate-400">
                        Suma de plata: {{ inRon(event.package.price) }}
                    </p>
                    <div class="grid md:grid-cols-2 gap-12 my-12">
                        <div>
                            <form id="payment-form">
                                <div ref="card">
                                    <!-- Elements will create input elements here -->
                                </div>
                                <div class="text-center">
                                    <spinkit v-if="paymentInProcess"></spinkit>
                                    <button v-else :disabled="paymentInProcess" id="submit"
                                        class="auth text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-xl text-xl px-4 py-2 text-center mt-6"
                                        @click="submitPayment" v-if="isStripeReady">Plateste
                                        {{ payment.price / 100 }} RON
                                    </button>
                                </div>
                            </form>
                            <button
                                class="text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 mt-4 text-center"
                                v-if="!isStripeReady" @click="initPayment(event.id)">Plateste cu cardul
                            </button>
                        </div>
                        <div class="flex flex-col justify-center items-center" v-if="isStripeReady">
                            <img src="/images/cards/stripe.png" alt="" class="w-1/2">
                            <div class="flex items-center justify-center">
                                <img src="/images/cards/1.png" alt="" class="h-12">
                                <img src="/images/cards/2.png" alt="" class="h-12">
                                <img src="/images/cards/3.png" alt="" class="h-12">
                                <img src="/images/cards/22.png" alt="" class="h-12">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div v-if="event.payment">
            <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg">
                <div class="grid md:grid-cols-2 gap-12">
                    <div class="ml-12">
                        <h3 class="text-2xl">Poze incarcate</h3>
                        <div v-if="event.picsCount">
                            <div v-if="event.picsCount === 1">
                                <p>A fost incarcata o poza</p>
                            </div>
                            <div v-else>
                                <p>Au fost incarcate {{ event.picsCount }} poze</p>
                            </div>
                            <p>Folosesti {{ formatBytes(event.picsSize) }} din
                                {{ event.package.limit ? event.package.limit + ' GB' : '&#8734;' }}</p>
                            <div v-if="event.package.limit" class="mb-4">
                                <div class="flex justify-end mb-1">
                                    <span class="text-sm font-medium text-orange-600 dark:text-white">{{
                                        usedDisk
                                    }}%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                                    <div class="bg-orange-500 h-2.5 rounded-full" :style="`width: ${usedDisk}%`"></div>
                                </div>
                            </div>
                        </div>
                        <p v-else>Nu ai incarcat nicio poza</p>
                    </div>
                    <div class="flex justify-center items-center" v-if="event.picsCount">
                        <router-link :to="`/client/events/${event.id}/gallery`"
                            class="flex text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-6 py-2 mt-0 md:mt-4 text-center">
                            <CameraIcon class="w-4 h-5 text-white me-2"></CameraIcon>
                            <span class="text-white">Vezi pozele</span>
                        </router-link>
                    </div>
                </div>
            </div>
            <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg">
                <div class="grid md:grid-cols-2">
                    <div class="ml-12">
                        <h3 class="text-2xl">Mesaje primite</h3>
                        <div v-if="event.messages.length">
                            <p>Ai primit {{ event.messages.length }} mesaje</p>
                        </div>
                        <p v-else>Nu ai primit niciun mesaj</p>
                    </div>
                    <div class="flex justify-center items-center" v-if="event.messages.length">
                        <div :class="!viewMessages ? 'flex justify-center items-center' : 'w-full'"
                            v-if="event.messages.length">
                            <button v-if="!viewMessages" @click="viewMessages = true"
                                class="flex text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-6 py-2 mt-0 md:mt-4 text-center">
                                <ChatBubbleBottomCenterTextIcon class="w-4 h-5 text-white me-2">
                                </ChatBubbleBottomCenterTextIcon>
                                <span class="text-white">Vezi mesajele</span>
                            </button>
                            <div class="relative w-full py-6" v-else>
                                <button class="absolute top-0 right-0" @click="viewMessages = false">
                                    <XMarkIcon class="w-4 h-4 text-slate-900"></XMarkIcon>
                                </button>
                                <div class="block relative overflow-y-scroll max-h-96">
                                    <div v-for="message in event.messages" :key="message.id">
                                        <span class="bg-slate-200 py-0.5 px-2 rounded me-1  block">{{ message.body }}</span>
                                        <span class="block text-sm text-right me-3 mb-5">~{{ message.guest.name }}~</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg">
                <div class="grid md:grid-cols-2 gap-12">
                    <div class="ml-12">
                        <h3 class="text-2xl">Invitati</h3>
                        <div v-if="event.guests.length">
                            <p>Ai <span v-if="event.pin">adaugat</span> {{ event.guests.length }} din {{ event.package.max_guests }} de invitati</p>
                            <div class="mb-4">
                                <div class="flex justify-end mb-1">
                                    <span class="text-sm font-medium text-orange-600 dark:text-white">{{
                                        usedGuests
                                    }}%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                                    <div class="bg-orange-500 h-2.5 rounded-full" :style="`width: ${usedGuests}%`"></div>
                                </div>
                            </div>
                        </div>
                        <p v-else>Nu ai <span v-if="event.pin">adaugat</span> niciun invitat</p>
                        <div v-if="event.pin">
                            <button
                                class="text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 mt-4 text-center"
                                v-if="!newGuest" @click="newGuest = true">Adauga invitat</button>
                            <div class="mt-4" v-else>
                                <input type="text"
                                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                                    placeholder="Scrie numele invitatului aici ..." autofocus v-model="guest.name">
                                <div v-if="v$.guest.name.required.$invalid && v$.guest.name.$dirty"
                                    class="text-sm text-red-500">
                                    Campul este
                                    obligatoriu
                                </div>
                                <input type="text"
                                    class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                                    placeholder="Scrie telefonul invitatului aici ..." v-model="guest.phone">
                                <div v-if="v$.guest.phone.required.$invalid && v$.guest.phone.$dirty"
                                    class="text-sm text-red-500">Campul este
                                    obligatoriu
                                </div>
                                <div v-if="v$.guest.phone.numeric.$invalid && v$.guest.phone.$dirty"
                                    class="text-sm text-red-500">
                                    Campul trebuie sa fie numeric
                                </div>
                                <div v-if="v$.guest.phone.minLength.$invalid && v$.guest.phone.$dirty"
                                    class="text-sm text-red-500">Campul trebuie sa contina minim 10 cifre
                                </div>
                                <div class="flex">
                                    <button
                                        class="text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 mt-4 me-4 text-center"
                                        @click="addGuest">Adauga invitat</button>
                                    <button
                                        class="text-white bg-slate-900 hover:bg-slate-800 focus:ring-4 focus:outline-none focus:ring-slate-300 font-medium rounded-full text-sm px-2 py-1 mt-4 text-center"
                                        @click="newGuest = false">Renunta</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div :class="!viewGuests ? 'flex justify-center items-center' : ''" v-if="event.guests.length">
                        <button v-if="!viewGuests" @click="viewGuests = true"
                            class="flex text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-6 py-2 mt-0 md:mt-4 text-center">
                            <UsersIcon class="w-4 h-5 text-white me-2"></UsersIcon>
                            <span class="text-white">Vezi invitatii</span>
                        </button>
                        <div class="relative w-full" v-else>
                            <button class="absolute top-0 right-0" @click="viewGuests = false">
                                <XMarkIcon class="w-4 h-4 text-slate-900"></XMarkIcon>
                            </button>
                            <input type="text"
                                class="mt-0 mb-2 block w-full px-0.5 border-0 border-b-2 border-slate-500 focus:ring-0 focus:border-slate-200"
                                placeholder="Cauta invitati dupa nume sau telefon ..." v-model="guestSearch">
                            <div class="block">
                                <span v-for="guest in guests" :key="guest.id"
                                    class="inline-flex bg-slate-200 text-sm mb-1 py-0.5 px-1 rounded-full me-1 whitespace-nowrap">{{ guest.name }}
                                    - {{ guest.phone }}
                                    <XMarkIcon
                                        class="w-3 h-3 bg-red-500 text-white rounded-full ms-1 mt-1 cursor-pointer"
                                        @click="removeGuest(guest)"
                                        v-if="event.pin"
                                    >
                                    </XMarkIcon>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg">
            <div class="grid md:grid-cols-2 gap-12">
                <div>
                    <div class="flex mb-6" v-if="!expanded.name">
                        <div class="basis-12">
                            <button @click="toggleInput('name')">
                                <PencilIcon class="h-10 w-6 text-orange-500 hover:text-orange-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>Numele evenimentului</label>
                            <h1 class="mb-4 text-4xl">{{ event.name }}</h1>
                        </div>
                    </div>
                    <div class="flex mb-6" v-else>
                        <div class="basis-12">
                            <button @click="editEvent('name')" :disabled="processing">
                                <DocumentCheckIcon class="h-10 w-6 text-teal-500 hover:text-teal-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>Numele evenimentului</label>
                            <input type="text"
                                class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                                placeholder="Scrie denumirea evenimentului tau aici ..." autofocus v-model="form.name">
                            <div v-if="v$.form.name.required.$invalid && v$.form.name.$dirty" class="text-sm text-red-500">
                                Campul e
                                obligatoriu
                            </div>
                        </div>
                    </div>
                    <div class="flex mb-6" v-if="!expanded.welcome">
                        <div class="basis-12">
                            <button @click="toggleInput('welcome')">
                                <PencilIcon class="h-10 w-6 text-orange-500 hover:text-orange-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>Mesajul de bun venit</label>
                            <h2 class="mb-4 text-xl italic text-slate-400 whitespace-pre-wrap" v-html="event.welcome"></h2>
                        </div>
                    </div>
                    <div class="flex mb-6" v-else>
                        <div class="basis-12">
                            <button @click="editEvent('welcome')" :disabled="processing">
                                <DocumentCheckIcon class="h-10 w-6 text-teal-500 hover:text-teal-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>Mesajul de bun venit</label>
                            <textarea
                                class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                                placeholder="Scrie mesajul pe care il vor vedea invitatii ..." autofocus
                                v-model="form.welcome"></textarea>
                        </div>
                    </div>

                    <div class="flex mb-6" v-if="!expanded.date">
                        <div class="basis-12">
                            <button @click="toggleInput('date')">
                                <PencilIcon class="h-10 w-6 text-orange-500 hover:text-orange-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>Data evenimentului</label>
                            <h2 class="mb-4 text-xl">{{ formatedDate(event.date) }}</h2>
                        </div>
                    </div>
                    <div class="flex mb-6" v-else>
                        <div class="basis-12">
                            <button @click="editEvent('date')" :disabled="processing">
                                <DocumentCheckIcon class="h-10 w-6 text-teal-500 hover:text-teal-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>Data evenimentului</label>
                            <VueDatePicker
                                class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                                placeholder="Adauga data evenimentului ..." v-model="form.date" :auto-apply="true"
                                :enable-time-picker="false" format="dd-MM-yyyy" model-type="yyyy-MM-dd" :min-date="now"
                                :month-change-on-scroll="false"></VueDatePicker>
                            <div v-if="v$.form.date.required.$invalid && v$.form.date.$dirty" class="text-sm text-red-500">
                                Campul e obligatoriu
                            </div>
                        </div>
                    </div>

                    <div class="flex mb-6" v-if="!expanded.pin">
                        <div class="basis-12">
                            <button @click="toggleInput('pin')">
                                <PencilIcon class="h-10 w-6 text-orange-500 hover:text-orange-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>PIN-ul evenimentului</label>
                            <h2 class="mb-4 text-xl mt-2" v-if="event.pin"><span
                                    class="w-6 h-10 border rounded-md inline-flex items-center justify-center border-slate-900 me-2"
                                    v-for="(pin, index) in arrayPin" :index="index">{{ pin }}</span></h2>
                            <h2 class="mb-4 text-xl" v-else>Eveniment fara PIN</h2>
                        </div>
                    </div>
                    <div class="flex mb-6" v-else>
                        <div class="basis-12">
                            <button @click="editEvent('pin')" :disabled="processing">
                                <DocumentCheckIcon class="h-10 w-6 text-teal-500 hover:text-teal-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <div class="mb-2">
                                <label class="font-medium block mb-3">Evenimentul necesita PIN</label>
                                <input id="checkbox-video" type="checkbox" v-model="form.has_pin"
                                       class="w-6 h-6 text-orange-500 bg-gray-100 border-gray-300 rounded focus:ring-orange-300 focus:ring-2" @input="form.pin=null">
                                <label for="checkbox-video" class="ms-2 text-sm">Foloseste PIN</label>
                            </div>
                            <div v-if="form.has_pin">
                                <label>PIN-ul evenimentului</label>
                                <input type="text"
                                       class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                                       placeholder="Seteaza PIN-ul evenimentului ..." v-model="form.pin">
                                <div v-if="v$.form.pin.required.$invalid && v$.form.pin.$dirty" class="text-sm text-red-500">
                                    Campul e obligatoriu
                                </div>
                                <div v-if="v$.form.pin.numeric.$invalid && v$.form.pin.$dirty" class="text-sm text-red-500">
                                    Campul
                                    trebuie sa fie numeric
                                </div>
                                <div v-if="v$.form.pin.minLength.$invalid && v$.form.pin.$dirty" class="text-sm text-red-500">
                                    Campul trebuie sa contina 4 cifre
                                </div>
                                <div v-if="v$.form.pin.maxLength.$invalid && v$.form.pin.$dirty" class="text-sm text-red-500">
                                    Campul trebuie sa contina 4 cifre
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex mb-6" v-if="!expanded.package_id">
                        <div class="basis-12">
                            <button @click="toggleInput('package_id')" v-if="!event.payment">
                                <PencilIcon class="h-10 w-6 text-orange-500 hover:text-orange-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>Packetul ales</label>
                            <h1 class="mb-4 text-xl">{{ event.package.name }} | {{ event.package.min_guests }} -
                                {{ event.package.max_guests }} Invitati | Foto {{event.package.videos?'& Video':''}} |
                                {{
                                    event.package.limit ? 'Maxim ' + event.package.limit + 'GB upload' : 'Fara limita de upload'
                                }}
                                | {{ inRon(event.package.price) }}</h1>
                        </div>
                    </div>
                    <div class="flex mb-6" v-else>
                        <div class="basis-12">
                            <button @click="editEvent('package_id')" :disabled="processing">
                                <DocumentCheckIcon class="h-10 w-6 text-teal-500 hover:text-teal-600" />
                            </button>
                        </div>
                        <div class="flex-1">
                            <label>Pachetul dorit</label>
                            <v-select id="sel" v-model="form.package_id" :options="packages" :reduce="op => op.id"
                                label="name" placeholder="Alege pachetul ..."
                                class="frontend mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4">
                                <template #option="{ name, min_guests, max_guests, limit, price, videos }">
                                    <span class="font-semibold">{{ name }}</span> |
                                    <span>{{ min_guests }} - {{
                                        max_guests
                                    }} Invitati | Foto {{videos?'& Video':''}} | {{
    limit ? 'Maxim ' + limit + 'GB upload' : 'Fara limita de upload'
}} | {{ inRon(price) }}</span>
                                </template>
                                <template #selected-option="{ name, min_guests, max_guests, limit, price, videos }">
                                    <span class="font-semibold pe-2">{{ name }}</span> | <span class="ps-2">{{ min_guests }}
                                        - {{
                                            max_guests
                                        }} Invitati | Foto {{videos?'& Video':''}} |
                                        {{ limit ? 'Maxim ' + limit + 'GB upload' : 'Fara limita de upload' }} | {{
                                            inRon(price)
                                        }}</span>
                                </template>
                                <template #no-options="{}">
                                    Niciun pachet gasit...
                                </template>
                            </v-select>
                            <div v-if="v$.form.package_id.required.$invalid && v$.form.package_id.$dirty"
                                class="text-sm text-red-500">Campul e obligatoriu
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col items-center justify-center">
                    <img :src="event.qrcode" alt="" class="w-1/2 md:w-1/4" />
                    <a :href="event.qrcode" download
                        class="text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 mt-4 text-center w-1/2 md:w-1/4">Descarca
                        cod QR</a>
                    <button
                        class="text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 mt-4 text-center w-1/2 md:w-1/4"
                        @click="copyLink">Copiaza link-ul
                    </button>
                </div>
            </div>
        </div>
        <div class="max-w-screen-xl mx-auto bg-white rounded-xl mb-12 flex shadow-lg" v-if="!form.featured">
            <vue-dropzone :multiple="false" accept="image/*" :max-files="1"
                :url="`/api/client/${user.id}/events/${event.id}/update-image`" @filesUploaded="setFiles"
                @filesErrors="showFilesErrors" @uploadError="showUploadError"></vue-dropzone>
        </div>
        <div v-else
            class="max-w-screen-xl mx-auto overflow-hidden max-h-48 mt-2 border rounded-xl flex flex-col justify-center items-center text-center relative">
            <img :src="form.featured" alt="" class="w-full">
            <div class="h-8 w-8 rounded-full absolute top-4 right-4 bg-white z-10 hover:bg-slate-800 group cursor-pointer"
                @click="form.featured = null">
                <div class="flex w-full h-full justify-center items-center">
                    <trash-icon class="w-6 h-6 text-red-500 group-hover:text-white"></trash-icon>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import {
    PencilIcon,
    DocumentCheckIcon,
    MinusCircleIcon,
    CheckCircleIcon,
    TrashIcon,
    CameraIcon,
    ChatBubbleBottomCenterTextIcon,
    XMarkIcon,
    UsersIcon
} from '@heroicons/vue/24/outline'
import {required, numeric, minLength, maxLength, requiredIf} from '@vuelidate/validators'
import moment from "moment";
import { useVuelidate } from "@vuelidate/core";
import VueDropzone from "../../components/VueDropzone";

const app_url = process.env.MIX_APP_URL

let key = process.env.MIX_STRIPE_KEY

export default {
    name: 'event-view',
    setup() {
        return {
            v$: useVuelidate()
        }
    },
    components: {
        PencilIcon,
        DocumentCheckIcon,
        MinusCircleIcon,
        CheckCircleIcon,
        TrashIcon,
        CameraIcon,
        ChatBubbleBottomCenterTextIcon,
        UsersIcon,
        XMarkIcon,
        VueDropzone
    },
    data() {
        return {
            dataLoaded: false,
            processing: false,
            newGuest: false,
            viewGuests: false,
            viewMessages: false,
            guestSearch: '',
            filters:{
                page:1
            },
            guest: {
                name: null,
                phone: null
            },
            form: {
                id: null,
                name: null,
                welcome: null,
                date: null,
                package_id: null,
                pin: null,
                has_pin:false,
                featured: null
            },
            expanded: {
                name: false,
                welcome: false,
                date: false,
                pin: false,
                package_id: false
            },
            payment: {
                clientSecret: null,
                price: null,
                stripe: null,
                elements: null,
                card: null
            },
            paymentInProcess: false
        }
    },
    validations() {
        return {
            form: {
                name: { required },
                date: { required },
                package_id: { required },
                pin: { required : requiredIf(this.form.has_pin), numeric, minLength: minLength(4), maxLength: maxLength(4) }
            },
            guest: {
                name: { required },
                phone: { required, numeric, minLength: minLength(10) }
            }
        }
    },
    notifications: {
        showSuccess: {
            title: 'Succes',
            message: 'Eveniment modificat cu succes!',
            type: 'success'
        },
        showError: {
            title: 'Eroare',
            message: 'Eroare!',
            type: 'error'
        }
    },
    computed: {
        ...mapGetters('events', {
            event: 'event'
        }),
        ...mapGetters('auth', {
            user: 'user'
        }),
        ...mapGetters('packages', {
            packages: 'packages'
        }),
        now() {
            return moment().format()
        },
        isStripeReady() {
            return !!this.payment.clientSecret
        },
        arrayPin() {
            return this.event.pin.split('')
        },
        usedDisk() {
            return Math.round(this.event.picsSize / (this.event.package.limit * 10000000))
        },
        usedGuests() {
            return Math.round(this.event.guests.length / this.event.package.max_guests * 100)
        },
        guests() {
            return this.event.guests.filter(x => x.name.toLowerCase().includes(this.guestSearch) || x.phone.includes(this.guestSearch))
        }
    },
    methods: {
        ...mapActions({
            getEvent: 'events/fetch',
            updateEvent: 'events/update',
            initEventPayment: 'events/initPayment',
            storePayment: 'events/storePayment',
            storeGuest: 'events/storeGuest',
            deleteGuest: 'events/deleteGuest',
        }),
        ...mapActions({
            getPackages: 'packages/bootstrap',
        }),
        destroyCard() {
            if (this.payment.elements) {
                this.payment.elements.getElement('payment').destroy()
            }
            this.payment = {
                clientSecret: null,
                price: null,
                stripe: null,
                elements: null,
                card: null
            }
        },
        initPayment(id) {
            let obj = {
                id: id,
            }
            this.initEventPayment(obj).then(
                (resp) => {
                    this.payment.clientSecret = resp.data.client_secret
                    this.payment.price = resp.data.amount

                    const clientSecret = resp.data.client_secret
                    const appearance = {
                        theme: 'stripe',
                        variables: {
                            colorPrimary: '#F97316',
                            colorBackground: '#FFFFFF',
                            colorText: '#30313D',
                            colorDanger: '#DF1B41',
                            fontFamily: 'Ideal Sans, system-ui, sans-serif',
                            spacingUnit: '2px',
                            borderRadius: '4px',
                        }
                    };

                    const options = {}

                    this.payment.stripe = Stripe(key, { locale: 'ro' })
                    this.payment.elements = this.payment.stripe.elements({ clientSecret, appearance })
                    this.payment.card = this.payment.elements.create("payment", options);
                    this.payment.card.mount(this.$refs.card);
                }
            ).catch(
                (err) => {
                    console.log(err)
                }
            )
        },
        submitPayment() {
            this.paymentInProcess = true
            let vm = this
            this.payment.stripe.confirmPayment({
                elements: vm.payment.elements,
                redirect: "if_required"
            }, vm).then(function (result) {
                if (result.error) {
                    // Show error to your customer (e.g., insufficient funds)
                    // this.showError({message:result.error.message})
                    console.log()
                    vm.showError({ message: result.error.message })
                    vm.payment.elements.getElement('payment').clear()
                    vm.paymentInProcess = false
                } else {
                    // The payment has been processed!
                    if (result.paymentIntent.status === 'succeeded') {
                        vm.showSuccess({ message: 'Plata a fost receptionata cu succes!' })
                        vm.payment.elements.getElement('payment').destroy()
                        vm.payment.clientSecret = null
                        vm.storePayment({ id: result.paymentIntent.id, event_id: vm.event.id }).then(
                            (resp) => {
                                vm.paymentInProcess = false
                                vm.showSuccess({ message: 'Evenimentul tau este activ!' })
                            }
                        )
                    }
                }
            })
        },
        toggleInput(type) {
            this.destroyCard()
            let expand = true
            Object.keys(this.expanded).forEach(key => {
                if (this.expanded[key] === true) {
                    expand = false
                }
            });
            this.expanded[type] = expand
        },
        setFiles(response) {
            this.showSuccess({ message: 'Imagine adaugata cu succes' })
            this.loadData()
        },
        showFilesErrors(data) {
            console.log(data)
            data.forEach(
                (x) => {
                    this.showError({ message: x.file ? x.file.name + ':' + x.errors[0].message : x.errors[0].message })
                }
            )
        },
        showUploadError(error) {
            this.showError({ message: error.message })
        },
        unsecuredCopyToClipboard(text) {
            const textArea = document.createElement("textarea");
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            try {
                document.execCommand('copy');
            } catch (err) {
                console.error('Unable to copy to clipboard', err);
            }
            document.body.removeChild(textArea);
        },
        copyLink() {
            const content = app_url + '/events/' + this.event.hash
            if (window.isSecureContext && navigator.clipboard) {
                navigator.clipboard.writeText(content);
            } else {
                this.unsecuredCopyToClipboard(content);
            }
            this.showSuccess({ message: 'Link-ul a fost copiat' })
        },
        formatedDate(date) {
            return moment(date).format('DD MMM YYYY')
        },
        inRon(value) {
            return 'RON ' + value / 100
        },
        formatBytes(a, b = 2) {
            if (!+a) return "0 Bytes";
            const c = 0 > b ? 0 : b, d = Math.floor(Math.log(a) / Math.log(1000));
            return `${parseFloat((a / Math.pow(1000, d)).toFixed(c))} ${["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][d]}`
        },
        async editEvent(type) {
            const result = await this.v$.form.$validate()
            if (!result) {
                return
            }
            if (type === 'date') {
                if (this.form.date === moment(this.event.date).format('YYYY-MM-DD')) {
                    this.toggleInput(type)
                    return
                }
            } else {
                if (this.form[type] === this.event[type]) {
                    this.toggleInput(type)
                    return
                }
            }

            this.processing = true
            let obj = {
                id: this.form.id,
                name: this.form.name,
                welcome: this.form.welcome,
                date: moment(this.form.date).format('YYYY-MM-DD'),
                pin: this.form.pin,
                package_id: this.form.package_id
            }
            this.updateEvent(obj).then(
                (resp) => {
                    this.showSuccess()
                    this.toggleInput(type)
                    this.loadData()
                }
            ).catch(
                (err) => {
                    this.showError({ message: err.message })
                }
            ).finally(
                this.processing = false
            )
        },
        async addGuest() {
            const result = await this.v$.guest.$validate()
            if (!result) {
                return
            }
            let obj = { ...this.guest, event_id: this.event.id }
            this.storeGuest(obj).then(
                (resp) => {
                    this.showSuccess({ message: 'Invitatul a fost adaugat cu succes' })
                    this.guest = {
                        name: null,
                        phone: null
                    }
                    this.newGuest = false
                }
            ).catch(
                (err) => {
                    this.showError({ message: err.message })
                }
            ).finally(
                this.processing = false
            )

        },
        async removeGuest(guest) {
            this.$swal({
                type: 'confirm',
                icon: 'warning',
                title: `Sterge invitat`,
                text: `Esti sigur ca vrei sa stergi invitatul ${guest.name}? Toate pozele si mesajele acestuia vor fi sterse de asemenea!`,
                confirmButtonText: 'Sterge',
                showCancelButton: true,
                cancelButtonText: 'Anuleaza',
            }).then(
                (result) => {
                    if (result.value) {
                        this.deleteGuest({ event_id: this.event.id, id: guest.id }).then(
                            (resp) => {
                                this.showSuccess({ message: 'Invitatul a fost sters cu succes' })
                            }
                        ).catch(
                            (err) => {
                                this.showError({ message: err.message })
                            }
                        )
                    }
                }
            )
        },
        async loadData() {
            this.getPackages()
            let params = {
                id:this.$route.params.id,
                page:this.filters.page,
            }
            this.getEvent(params).then(
                (resp) => {
                    this.form.id = this.event.id
                    this.form.name = this.event.name
                    this.form.welcome = this.event.welcome
                    this.form.date = moment(this.event.date).format('YYYY-MM-DD')
                    this.form.package_id = this.event.package_id
                    this.form.has_pin = this.event.pin?true:false
                    this.form.pin = this.event.pin
                    this.form.featured = this.event.featured
                    this.dataLoaded = true
                }
            ).catch(
                (err) => {
                    this.showError({ message: err.message })
                }
            )
        }
    },
    mounted() {
        this.loadData()
    }
}
</script>
