<template>
    <section v-if="dataLoaded" class="w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto bg-white rounded-xl shadow-lg">
        <div class="text-center mb-12">
            <h1 class="mb-4 text-4xl">Posteaza un Mesaj</h1>
        </div>
        <div class="mb-12">
            <textarea
                class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                placeholder="Trimite un mesaj" v-model="form.body"></textarea>
            <div v-if="v$.form.body.required.$invalid && v$.form.body.$dirty" class="text-sm text-red-500">Campul e
                obligatoriu</div>
        </div>
        <div class="flex justify-center items-center">
            <router-link :to="`/events/${event.hash}`" class="bg-slate-900 px-4 me-4 hover:bg-slate-600 text-center text-white text-xl py-2 rounded-full mb-12">
                Renunta
            </router-link>
            <button :disabled="processing"
                class="bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full mb-12"
                @click="trySendMessage">Trimite Mesajul</button>
        </div>
    </section>
</template>

<script>
import { required } from '@vuelidate/validators'
import { useVuelidate } from '@vuelidate/core'
import { mapActions, mapGetters } from "vuex";
export default {
    name: "Message",
    setup() {
        return {
            v$: useVuelidate()
        }
    },
    data() {
        return {
            dataLoaded: false,
            processing: false,
            form: {
                body: null
            }
        }
    },
    validations() {
        return {
            form: {
                body: { required },
            }
        }
    },
    notifications: {
        showSuccess: {
            title: 'Succes',
            message: 'Mesaj trimis cu succes!',
            type: 'success'
        },
        showError: {
            title: 'Eroare',
            message: 'Eroare!',
            type: 'error'
        }
    },
    computed: {
        ...mapGetters('events', {
            event: 'event'
        }),
        ...mapGetters('events', {
            isGuestAuthenticated: 'isGuestAuthenticated',
            guest: 'guest'
        }),
    },
    methods: {
        ...mapActions({
            getEvent: 'events/fetchForGuest',
            sendMessage: 'events/storeMessage'
        }),
        async trySendMessage() {
            const result = await this.v$.$validate()
            if (!result) {
                return
            }
            this.processing = true
            let obj = {
                ...this.form,
                guest_hash: this.guest.hash,
                hash: this.event.hash
            }
            this.sendMessage(obj).then(
                () => {
                    this.showSuccess()
                }
            ).catch(
                (err) => this.showError({
                    message: err.message
                })
            ).finally(
                this.processing = false
            )

        },
        async loadData() {
            let params = {
                hash:this.$route.params.hash,
                guest:this.guest.hash,
                page:1,
                gallery:false
            }
            this.getEvent(params).then(
                (resp) => this.dataLoaded = true
            ).catch(
                (err) => this.showError({ message: err.message })
            )
        }


    },
    mounted() {
        this.loadData()
    }



}
</script>
