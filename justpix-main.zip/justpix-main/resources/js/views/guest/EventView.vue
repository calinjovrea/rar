<template>
    <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg" v-if="dataLoaded">
        <h1 class="mb-4 text-4xl text-center">{{ event.name }}</h1>
        <h3 class="mb-4 text-xl italic text-center text-slate-400" v-if="guest">Salut {{guest.name}}</h3>
        <h2 class="mb-4 text-2xl italic text-center whitespace-pre-wrap" v-html="event.welcome"></h2>
        <div v-if="event.featured"
             class="max-w-screen-xl mx-auto overflow-hidden h-96 mt-2 border rounded-xl flex flex-col justify-center items-center text-center relative">
            <img :src="event.featured" alt="" class="md:h-full md:w-auto w-full h-auto">
        </div>
        <div v-if="event.payments.length">
            <div v-if="isGuestAuthenticated">
                <div class="mt-12 w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto">
                    <button v-if="eventHasSpace&&!viewUpload"
                            class="flex bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full my-6 text-center justify-center items-center"
                            @click="viewUpload = true">
                        <CloudArrowUpIcon class="w-5 h-7 text-white me-2"></CloudArrowUpIcon>
                        <span class="text-white">Incarca poze</span>
                    </button>
                    <p v-else-if="!eventHasSpace" class="text-red-500 text-xl py-2 my-6 text-center">Evenimentul a atins limita maxima de upload!</p>
                    <div class="max-w-screen-xl mx-auto bg-white rounded-xl mb-12 flex shadow-lg" v-else>
                        <vue-dropzone :multiple="true" :accept="acceptedTypes" :max-files="20"
                                      :url="`/guest/${guest.hash}/events/${event.hash}/upload`" @filesUploaded="setFiles"
                                      @filesErrors="showFilesErrors" @uploadError="showUploadError"></vue-dropzone>
                    </div>
                    <router-link
                        class="flex bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full my-6 text-center justify-center items-center"
                        :to="`/events/${$route.params.hash}/gallery`">
                        <CameraIcon class="w-5 h-7 text-white me-2"></CameraIcon>
                        <span class="text-white">Galeria evenimentului</span>
                    </router-link>
                    <router-link :to="'/events/' + $route.params.hash + '/message'"
                                 class="flex bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full my-6 text-center justify-center items-center">
                        <ChatBubbleBottomCenterTextIcon
                            class="w-5 h-7 text-white me-2"></ChatBubbleBottomCenterTextIcon>
                        <span class="text-white">Posteaza mesaje</span>
                    </router-link>
                </div>
            </div>
            <div v-else class="mt-12 w-full md:w-1/2 p-4 mx-auto max-w-screen-xl mx-auto">
                <input type="text"
                       class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                       placeholder="Introdu numarul de telefon aici ..." autofocus v-model="form.phone">
                <div v-if="v$.form.phone.required.$invalid && v$.form.phone.$dirty" class="text-sm text-red-500">Campul
                    e
                    obligatoriu
                </div>
                <div v-if="v$.form.phone.numeric.$invalid && v$.form.phone.$dirty" class="text-sm text-red-500">Campul
                    trebuie
                    sa
                    fie numeric
                </div>
                <div v-if="v$.form.phone.minLength.$invalid && v$.form.phone.$dirty" class="text-sm text-red-500">Campul
                    trebuie
                    sa contina minim 10 cifre
                </div>
                <div v-if="event.pin">
                    <input type="text"
                           class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                           placeholder="Scrie PIN-ul evenimentului aici ..." v-model="form.pin">
                    <div v-if="v$.form.pin.required.$invalid && v$.form.pin.$dirty" class="text-sm text-red-500">Campul e
                        obligatoriu
                    </div>
                    <div v-if="v$.form.pin.numeric.$invalid && v$.form.pin.$dirty" class="text-sm text-red-500">Campul
                        trebuie sa
                        fie
                        numeric
                    </div>
                    <div v-if="v$.form.pin.minLength.$invalid && v$.form.pin.$dirty" class="text-sm text-red-500">Campul
                        trebuie sa
                        contina 4 cifre
                    </div>
                    <div v-if="v$.form.pin.maxLength.$invalid && v$.form.pin.$dirty" class="text-sm text-red-500">Campul
                        trebuie sa
                        contina 4 cifre
                    </div>
                </div>
                <div v-else>
                    <input type="text"
                           class="mt-0 block w-full px-0.5 border-0 border-b-2 border-orange-500 focus:ring-0 focus:border-orange-600 focus:border-b-4"
                           placeholder="Introdu numele tau aici ..." v-model="form.name">
                    <div v-if="v$.form.name.required.$invalid && v$.form.name.$dirty" class="text-sm text-red-500">Campul
                        e
                        obligatoriu
                    </div>
                </div>
                <div class="flex justify-center items-center">
                    <button :disabled="processing"
                            class="bg-orange-500 hover:bg-orange-600  w-full text-white text-xl py-2 rounded-full my-12"
                            @click="tryLoginGuest">Intra in eveniment
                    </button>
                </div>
            </div>
        </div>
        <h1 class="text-2xl text-center m-5" v-else>Evenimentul nu este activ inca</h1>
    </div>
    <div v-if="dataLoaded && isGuestAuthenticated && pics.length && event.payments.length">
        <div class="max-w-screen-xl mx-auto p-4 bg-white rounded-xl mb-12 shadow-lg">
            <h3 class="mb-3 text-xl">Poze incarcate de tine:</h3>
            <div class="columns-2 md:columns-3 lg:columns-4 gap-3">
                <div
                    class="relative overflow-hidden w-full flex items-center justify-center mb-2  rounded"
                    v-for="image in pics" :key="image.id">
                    <a :href="`/storage/${image.id}/${image.file_name}`" download class="absolute top-2 left-2 z-10">
                        <CloudArrowDownIcon
                            class="bg-orange-600 text-white rounded-full hover:bg-orange-700 w-4 h-4 md:w-6 md:h-6 p-1">
                        </CloudArrowDownIcon>
                    </a>
                    <TrashIcon @click="tryDeletePhoto(image.id)"
                               class="absolute top-2 right-2 bg-white text-red-500 rounded-full hover:bg-slate-100 w-4 h-4 md:w-6 md:h-6 p-1 z-10">
                    </TrashIcon>
                    <div v-if="isImage(image)">
                        <img :src="`${image.original_url}`" alt="">
                    </div>
                    <div v-else>
                        <video controls>
                            <source :src="`${image.original_url}`" :type="image.mime_type">
                        </video>
                    </div>
                </div>
            </div>
            <div class="flex">
                <button class="text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-orange-300 font-medium rounded-full text-sm px-2 py-1 text-center mx-auto my-12" v-if="filters.page < event.pics.last_page" @click="loadMore()">Arata mai multe</button>
            </div>
        </div>
    </div>
</template>

<script>
import {mapActions, mapGetters} from "vuex";
import {required, numeric, minLength, maxLength, requiredIf} from '@vuelidate/validators'
import {useVuelidate} from "@vuelidate/core";
import {
    CameraIcon,
    ChatBubbleBottomCenterTextIcon,
    CloudArrowUpIcon,
    CloudArrowDownIcon,
    TrashIcon
} from '@heroicons/vue/24/outline'
import VueDropzone from "../../components/VueDropzone";

export default {
    name: 'event-view',
    setup() {
        return {
            v$: useVuelidate()
        }
    },
    components: {
        CameraIcon,
        ChatBubbleBottomCenterTextIcon,
        CloudArrowUpIcon,
        VueDropzone,
        CloudArrowDownIcon,
        TrashIcon
    },
    data() {
        return {
            dataLoaded: false,
            processing: false,
            viewUpload: false,
            form: {
                phone: null,
                pin: null,
                name: null
            },
            filters:{
                page:1
            }
        }
    },
    validations() {
        return {
            form: {
                phone: {required, numeric, minLength: minLength(10)},
                pin: {required:requiredIf(this.event&&this.event.pin), numeric, minLength: minLength(4), maxLength: maxLength(4)},
                name: {required:requiredIf(this.event&&!this.event.pin)}
            }
        }
    },
    notifications: {
        showSuccess: {
            title: 'Succes',
            message: 'Ai intrat cu succes in pagina evenimentului!',
            type: 'success'
        },
        showError: {
            title: 'Eroare',
            message: 'Eroare!',
            type: 'error'
        }
    },
    computed: {
        ...mapGetters('events', {
            event: 'event',
            pics: 'pics',
            isGuestAuthenticated: 'isGuestAuthenticated',
            guest: 'guest'
        }),
        acceptedTypes(){
            if (this.event.package.videos){
                return ['image/*', 'video/mp4', 'video/quicktime']
            }else{
                return ['image/*']
            }
        },
        eventHasSpace(){
            if (this.event.package.limit){
                return this.event.picsSize < this.event.package.limit*1000000000
            }
            return true
        }
    },
    methods: {
        ...mapActions({
            getEvent: 'events/fetchForGuest',
            loginGuest: 'events/loginGuest',
            deletePhoto: 'events/deletePhoto',
            getPics: 'events/getPics'
        }),
        isImage(image){
            return image.mime_type.includes('image')
        },
        loadMore(){
            this.filters.page +=1
            let params = {
                hash:this.$route.params.hash,
                guest:this.guest?this.guest.hash:null,
                page:this.filters.page,
                gallery:false
            }
            this.getPics(params).then(
                (resp) => true
            ).catch(
                (err) => {
                    this.showError({message: err.message})
                    this.filters.page -=1
                }
            )
        },
        async tryLoginGuest() {
            const result = await this.v$.form.$validate()
            if (!result) {
                return
            }
            this.processing = true
            const obj = {...this.form, event_id: this.event.id}
            this.loginGuest(obj).then(
                (resp) => {
                    this.showSuccess()
                    this.loadData()
                }
            ).catch(
                (err) => {
                    console.log(err)
                    if (err.status = 422) {
                        this.showError({message: err.response.data})
                    } else {
                        this.showError({message: err.message})
                    }
                }
            ).finally(
                this.processing = false
            )
        },
        setFiles(response) {
            this.showSuccess({message: 'Imagini adaugate cu succes'})
            this.filters.page=1
            this.loadData()
            this.viewUpload = false
        },
        showFilesErrors(data) {
            console.log(data)
            data.forEach(
                (x) => {
                    this.showError({message: x.file ? x.file.name + ':' + x.errors[0].message : x.errors[0].message})
                }
            )
        },
        showUploadError(error) {
            this.showError({message: error.message})
        },
        async loadData() {
            let params = {
                hash:this.$route.params.hash,
                guest:this.guest?this.guest.hash:null,
                page:this.filters.page,
                gallery:false
            }
            this.getEvent(params).then(
                (resp) => this.dataLoaded = true
            ).catch(
                (err) => this.showError({message: err.message})
            )
        },
        tryDeletePhoto(id) {
            this.$swal({
                type: 'confirm',
                icon: 'warning',
                title: `Sterge Poza`,
                text: `Esti sigur ca vrei sa stergi poza?`,
                confirmButtonText: 'Accept',
                showCancelButton: true,
                cancelButtonText: 'Anuleaza',
            }).then(
                (result) => {
                    if (result.value) {
                        let obj = {
                            id: id,
                            guest_hash: this.guest.hash
                        }
                        this.deletePhoto(obj).then(
                            (resp) => {
                                this.showSuccess({message: 'Poza a fost stearsa cu succes!'})
                            }
                        ).catch(
                            (err) => {
                                this.showError({message: err.message})
                            }
                        )
                    }
                }
            )
        },
    },
    mounted() {
        this.loadData()
    }

}
</script>
