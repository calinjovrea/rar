<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'admin', 'middleware' => ['auth:sanctum']], function () {
    Route::get('/packages', [\App\Http\Controllers\PackagesController::class, 'index']);
    Route::group(['middleware' => ['role:Superadmin']], function () {
        Route::get('/packages/{package}', [\App\Http\Controllers\PackagesController::class, 'fetch']);
        Route::post('/packages/{package}/update', [\App\Http\Controllers\PackagesController::class, 'update']);
        Route::post('/packages/{package}/delete', [\App\Http\Controllers\PackagesController::class, 'delete']);
        Route::post('/packages/store', [\App\Http\Controllers\PackagesController::class, 'store']);
        Route::get('/users', [\App\Http\Controllers\UsersController::class, 'index']);
        Route::get('/users/{user}', [\App\Http\Controllers\UsersController::class, 'fetch']);
        Route::post('/users/{user}/update', [\App\Http\Controllers\UsersController::class, 'update']);
        Route::post('/users/{user}/delete', [\App\Http\Controllers\UsersController::class, 'delete']);
        Route::post('/users/store', [\App\Http\Controllers\UsersController::class, 'store']);
    });
    Route::group(['middleware' => ['role:Superadmin|Admin']], function () {
        Route::get('/dashboard', [\App\Http\Controllers\EventsController::class, 'getAllEvents']);
    });
});

Route::group(['prefix' => 'client', 'middleware' => ['auth:sanctum']], function () {
    Route::post('/single-upload', [\App\Http\Controllers\EventsController::class, 'singleUpload']);
    Route::get('/{user}/events', [\App\Http\Controllers\EventsController::class, 'index']);
    Route::post('/{user}/events/store', [\App\Http\Controllers\EventsController::class, 'store']);
    Route::group(['middleware' => ['check-user-event']], function () {
        Route::get('/{user}/events/{event}', [\App\Http\Controllers\EventsController::class, 'fetch']);
        Route::get('/{user}/events/{event}/pics', [\App\Http\Controllers\EventsController::class, 'getClientPics']);
        Route::post('/{user}/events/{event}/update', [\App\Http\Controllers\EventsController::class, 'update']);
        Route::post('/{user}/events/{event}/zip', [\App\Http\Controllers\EventsController::class, 'zipClient']);
        Route::post('/{user}/events/{event}/update-image', [\App\Http\Controllers\EventsController::class, 'updateImage']);
        Route::post('/{user}/events/{event}/initiate-payment', [\App\Http\Controllers\PaymentsController::class, 'initiatePayment']);
        Route::post('/{user}/events/{event}/complete-payment', [\App\Http\Controllers\PaymentsController::class, 'completePayment']);
        Route::post('/{user}/events/{event}/store-guest', [\App\Http\Controllers\EventsController::class, 'storeGuest']);
        Route::post('/{user}/events/{event}/delete-guest', [\App\Http\Controllers\EventsController::class, 'deleteGuest']);
    });
    Route::group(['middleware' => ['check-media-user']], function () {
        Route::post('/{user}/media/{media}/delete', [\App\Http\Controllers\EventsController::class, 'deleteClientPhoto']);
    });
});
