<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::post('/guest/events/{event}/login', [\App\Http\Controllers\EventsController::class, 'loginGuest']);
Route::get('/guest/{guest}/events/{hash}', [\App\Http\Controllers\EventsController::class, 'getForGuest']);
Route::group(['middleware' => ['check-media']], function () {
    Route::post('/guest/{guest}/media/{media}/delete', [\App\Http\Controllers\EventsController::class, 'deletePhoto']);
});
Route::group(['middleware' => ['check-event']], function () {
    Route::post('/guest/{guest}/events/{hash}/message', [\App\Http\Controllers\EventsController::class, 'message']);
    Route::post('/guest/{guest}/events/{hash}/zip', [\App\Http\Controllers\EventsController::class, 'zip']);
    Route::post('/guest/{guest}/events/{hash}/upload', [\App\Http\Controllers\EventsController::class, 'upload']);
    Route::get('/guest/{guest}/events/{hash}/pics', [\App\Http\Controllers\EventsController::class, 'getPics']);
});


Route::get('/{vue?}', function () {
    return view('app');
})->where('vue', '[\/\w\.-]*')->name('home');

//Route::get('{any}', function () {
//    return view('app');
//})->where('any', '.*');

Auth::routes();
