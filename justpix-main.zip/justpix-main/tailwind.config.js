/** @type {import('tailwindcss').Config} */
export default {
  content: [
      "./resources/**/*.blade.php",
      "./resources/**/*.js",
      "./resources/**/*.vue",
  ],
  theme: {
    extend: {
        flex:{
            '2':'2 2 0%',
            '3':'3 3 0%',
            '4':'4 4 0%',
            '5':'5 5 0%',
            '6':'6 6 0%',
        },
        keyframes: {
            'open-menu': {
                '0%': { transform: 'scaleY(0)' },
                '80%': { transform: 'scaleY(1.2)' },
                '100%': { transform: 'scaleY(1)' },
            },
        },
        animation: {
            'open-menu': 'open-menu 0.5s ease-in-out forwards',
        }
    },
  },
  plugins: [
      require('@tailwindcss/forms'),
  ],
}

