const mix = require('laravel-mix');
const path = require("path");

mix.webpackConfig({
    resolve: {
        alias: {
            '@': path.resolve(__dirname, 'resources/js'),
            '@assets': path.resolve(__dirname, 'resources/js/assets'),
            '@scss': path.resolve(__dirname, 'resources/scss')
        }
    },
    output: {
        chunkFilename: '[name].js?id=[chunkhash]',
    },
    stats: {
        children: true,
    }
})

mix.js('resources/js/app.js', 'public/js').vue().version();
mix.sass('resources/scss/app.scss', 'public/css').options({
    processCssUrls: false
});
